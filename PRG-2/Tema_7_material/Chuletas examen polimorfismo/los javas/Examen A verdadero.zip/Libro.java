public class Libro extends Publicacion implements Prestable {
    private String autor;
    private boolean prestado;

    public Libro(int codigo, String titulo, String autor) {
        super(codigo, titulo);
        this.autor = autor;
        this.prestado = false;
    }

    @Override
    public void prestar() { this.prestado = true; }

    @Override
    public void devolver() { this.prestado = false; }

    @Override
    public boolean estaDisponible() { return !prestado; }

    public String getAutor() { return autor; }
    public boolean isPrestado() { return prestado; }

    @Override
    public String toString() {
        return "Libro[codigo=" + getCodigo() + ", titulo=" + getTitulo()
             + ", autor=" + autor + ", prestado=" + prestado + "]";
    }
}
