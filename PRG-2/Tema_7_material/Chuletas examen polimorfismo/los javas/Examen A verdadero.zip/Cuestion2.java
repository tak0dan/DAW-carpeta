import java.util.ArrayList;
import java.util.Random;

interface Procesable {
    void procesar();
}

class A implements Procesable {
    @Override
    public void procesar() {
        System.out.println("Procesando A");
    }
}

class B implements Procesable {
    @Override
    public void procesar() {
        System.out.println("Procesando B");
    }
}

public class Cuestion2 {

    public static void processAllTheList(ArrayList<Procesable> l) {
        for (Procesable p : l) {
            p.procesar();
        }
    }

    public static void main(String[] args) {
        ArrayList<Procesable> li = new ArrayList<>();
        Random r = new Random();

        for (int i = 1; i <= 10; i++) {
            if (r.nextDouble() > 0.5)
                li.add(new A());
            else
                li.add(new B());
        }

        processAllTheList(li);
    }
}
