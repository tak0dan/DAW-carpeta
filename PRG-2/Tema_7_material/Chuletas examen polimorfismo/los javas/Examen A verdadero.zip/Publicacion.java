public abstract class Publicacion implements Comparable<Publicacion> {
    private int codigo;
    private String titulo;

    public Publicacion(int codigo, String titulo) {
        this.codigo = codigo;
        this.titulo = titulo;
    }

    public int getCodigo() { return codigo; }
    public String getTitulo() { return titulo; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Publicacion)) return false;
        return this.codigo == ((Publicacion) o).codigo;
    }

    @Override
    public int compareTo(Publicacion otra) {
        return Integer.compare(this.codigo, otra.codigo);
    }

    @Override
    public String toString() {
        return "Publicacion[codigo=" + codigo + ", titulo=" + titulo + "]";
    }
}
