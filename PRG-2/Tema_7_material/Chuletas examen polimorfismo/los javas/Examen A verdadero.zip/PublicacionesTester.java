import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class PublicacionesTester {

    // Apartado b) — con for-each
    public static void cuantosLibrosCuantasRevistas(ArrayList<Publicacion> l) {
        int numLibros = 0;
        int numRevistas = 0;
        int librosEnBiblioteca = 0;

        for (Publicacion p : l) {
            if (p instanceof Libro) {
                numLibros++;
                if (((Libro) p).estaDisponible()) {
                    librosEnBiblioteca++;
                }
            } else if (p instanceof Revista) {
                numRevistas++;
            }
        }

        System.out.println("Hay " + numRevistas + " revistas y " + numLibros
            + " libros; solo " + librosEnBiblioteca
            + " de estos libros se encuentran actualmente en la biblioteca");
    }

    // Apartado f) — con Iterator
    public static void cuantosLibrosCuantasRevistasIterator(ArrayList<Publicacion> l) {
        int numLibros = 0;
        int numRevistas = 0;
        int librosEnBiblioteca = 0;

        Iterator<Publicacion> it = l.iterator();
        while (it.hasNext()) {
            Publicacion p = it.next();
            if (p instanceof Libro) {
                numLibros++;
                if (((Libro) p).estaDisponible()) {
                    librosEnBiblioteca++;
                }
            } else if (p instanceof Revista) {
                numRevistas++;
            }
        }

        System.out.println("Hay " + numRevistas + " revistas y " + numLibros
            + " libros; solo " + librosEnBiblioteca
            + " de estos libros se encuentran actualmente en la biblioteca");
    }

    // Apartados d) y e)
    public static void main(String[] args) {
        ArrayList<Publicacion> lista = new ArrayList<>();

        // 3 revistas (menos de 5)
        lista.add(new Revista(3,  "National Geographic", "mensual"));
        lista.add(new Revista(7,  "El País Semanal",     "semanal"));
        lista.add(new Revista(11, "Time",                "semanal"));

        // 7 libros (más de 5)
        Libro l1 = new Libro(1,  "Don Quijote",          "Cervantes");
        Libro l2 = new Libro(2,  "1984",                 "Orwell");
        Libro l3 = new Libro(5,  "El Principito",        "Saint-Exupéry");
        Libro l4 = new Libro(6,  "Cien Años de Soledad", "García Márquez");
        Libro l5 = new Libro(8,  "Harry Potter",         "Rowling");
        Libro l6 = new Libro(9,  "La Odisea",            "Homero");
        Libro l7 = new Libro(10, "Hamlet",               "Shakespeare");

        // Algunos libros prestados
        l2.prestar();
        l4.prestar();
        l6.prestar();

        lista.add(l1); lista.add(l2); lista.add(l3); lista.add(l4);
        lista.add(l5); lista.add(l6); lista.add(l7);

        // Apartado b)
        cuantosLibrosCuantasRevistas(lista);

        // Apartado e) — ordenar y mostrar
        Collections.sort(lista);
        System.out.println("\nLista ordenada:");
        for (Publicacion p : lista) {
            System.out.println(p);
        }
    }
}
