abstract class Base {
    protected int i;

    public Base(int i) {
        this.i = i;
    }
}

class Derivada extends Base {
    public Derivada(int i) {
        super(i);
    }

    public void metodo() {
        System.out.println(i);
    }
}

public class Cuestion4 {
    public static void main(String[] args) {
        Derivada[] v = new Derivada[10];
        for (int i = 0; i < 10; i++) {
            v[i] = new Derivada(i);
            v[i].metodo();
        }
    }
}
