public class Revista extends Publicacion {
    private String periodicidad;

    public Revista(int codigo, String titulo, String periodicidad) {
        super(codigo, titulo);
        this.periodicidad = periodicidad;
    }

    public String getPeriodicidad() { return periodicidad; }

    @Override
    public String toString() {
        return "Revista[codigo=" + getCodigo() + ", titulo=" + getTitulo()
             + ", periodicidad=" + periodicidad + "]";
    }
}
