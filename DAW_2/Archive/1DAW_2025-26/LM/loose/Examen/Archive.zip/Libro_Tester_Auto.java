public class Libro_Tester_Auto {

    public static void main(String[] args) {
        System.out.println("=== Auto-generated tester for Libro ===");

        // Create with default constructor
        Libro libro1 = new Libro();
        System.out.println("Default: " + libro1);
        Libro libro2 = new Libro("val_titulo", "val_autor", "val_isbn");
        System.out.println("Parametrized: " + libro2);
        libro2.setTitulo(null);
        libro2.setAutor(null);
        System.out.println("after set -> getTitulo() = " + libro2.getTitulo());
        System.out.println("after set -> getIsbn() = " + libro2.getIsbn());
        System.out.println("=== End ===");
    }
}