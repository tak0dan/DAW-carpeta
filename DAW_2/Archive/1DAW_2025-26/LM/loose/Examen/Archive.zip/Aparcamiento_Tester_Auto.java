public class Aparcamiento_Tester_Auto {

    public static void main(String[] args) {
        Aparcamiento aparcamiento = new Aparcamiento();

        System.out.println("=== Auto-generated tester for Aparcamiento ===");
        System.out.println("Empty: " + aparcamiento);

        // ---- add items ----
        aparcamiento.anyadirPlazaAparcamiento(new PlazaAparcamiento(1, false, "item1_matriculaVehiculo"));
        aparcamiento.anyadirPlazaAparcamiento(new PlazaAparcamiento(2, false, "item2_matriculaVehiculo"));
        aparcamiento.anyadirPlazaAparcamiento(new PlazaAparcamiento(3, false, "item3_matriculaVehiculo"));
        System.out.println("After add 3: " + aparcamiento);
        System.out.println("plazasLibres() = " + aparcamiento.plazasLibres());
        System.out.println("plazasOcupadas() = " + aparcamiento.plazasOcupadas());
        System.out.println("Searching...");
        System.out.println("buscarPlaza(1): " + aparcamiento.buscarPlaza(1));
        System.out.println("buscarPlaza(99): " + aparcamiento.buscarPlaza(99));
        System.out.println("Removing...");
        aparcamiento.liberarVehiculo("item1_plazas");
        System.out.println("After remove: " + aparcamiento);
        System.out.println("Counts...");
        System.out.println("  plazasLibres() = " + aparcamiento.plazasLibres());
        System.out.println("  plazasOcupadas() = " + aparcamiento.plazasOcupadas());
        System.out.println("\nUsing Iterator:");
        java.util.Iterator<PlazaAparcamiento> it = java.util.Arrays.asList(new PlazaAparcamiento[0]).iterator(); // placeholder
        System.out.println("=== End ===");
    }
}