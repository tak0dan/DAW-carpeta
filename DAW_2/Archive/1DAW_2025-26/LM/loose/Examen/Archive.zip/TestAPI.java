public class TestAPI {
    public static void main(String[] args) throws Exception {
        OpenRouterClient client = new OpenRouterClient(
            "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"
        );
        String resp = client.chat("Di solo 'Hola Mundo' en una línea.");
        System.out.println("RESP: " + resp);
        System.out.println("---END---");
    }
}
