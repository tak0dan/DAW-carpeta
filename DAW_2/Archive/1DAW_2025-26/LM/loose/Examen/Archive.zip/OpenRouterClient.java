import java.io.*;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.*;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.*;

public class OpenRouterClient {

    static final String API_URL = "https://openrouter.ai/api/v1/chat/completions";
    static final String DEFAULT_MODEL = "openrouter/free";
    static final String SITE_URL = "https://github.com/anomalyco/opencode";
    static final String SITE_NAME = "Exam2Java";

    final String apiKey;
    final String model;

    public OpenRouterClient(String apiKey) {
        this(apiKey, DEFAULT_MODEL);
    }

    public OpenRouterClient(String apiKey, String model) {
        this.apiKey = apiKey;
        this.model = model;
    }

    public String chat(String systemPrompt, String userPrompt) throws Exception {
        HttpClient client = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(60))
            .build();

        String body = buildRequestBody(systemPrompt, userPrompt);

        HttpRequest req = HttpRequest.newBuilder()
            .uri(URI.create(API_URL))
            .header("Authorization", "Bearer " + apiKey)
            .header("Content-Type", "application/json")
            .header("HTTP-Referer", SITE_URL)
            .header("X-Title", SITE_NAME)
            .timeout(Duration.ofSeconds(120))
            .POST(HttpRequest.BodyPublishers.ofString(body, StandardCharsets.UTF_8))
            .build();

        HttpResponse<String> resp = client.send(req, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));

        if (resp.statusCode() != 200) {
            return "ERROR " + resp.statusCode() + ": " + resp.body();
        }

        return extractContent(resp.body());
    }

    public String chat(String userPrompt) throws Exception {
        return chat("Eres un asistente experto en Java y generación de código.", userPrompt);
    }

    String buildRequestBody(String system, String user) {
        // Minimal JSON serialization, no external libs
        StringBuilder sb = new StringBuilder();
        sb.append("{\n");
        sb.append("  \"model\": \"").append(escapeJson(model)).append("\",\n");
        sb.append("  \"messages\": [\n");
        sb.append("    {\"role\": \"system\", \"content\": \"").append(escapeJson(system)).append("\"},\n");
        sb.append("    {\"role\": \"user\", \"content\": \"").append(escapeJson(user)).append("\"}\n");
        sb.append("  ],\n");
        sb.append("  \"temperature\": 0.2,\n");
        sb.append("  \"max_tokens\": 4096\n");
        sb.append("}");
        return sb.toString();
    }

    static String escapeJson(String s) {
        return s.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t");
    }

    // Extract "content" field from OpenAI-style response JSON
    // Uses simple char-by-char parsing to avoid external JSON libs
    static String extractContent(String json) {
        // Find "content": "..." — handle escaped quotes inside
        String marker = "\"content\": \"";
        int idx = json.indexOf(marker);
        if (idx < 0) {
            // Try alternate format
            marker = "\"content\" : \"";
            idx = json.indexOf(marker);
            if (idx < 0) return json; // fallback: return raw
        }
        idx += marker.length();
        StringBuilder content = new StringBuilder();
        boolean escaped = false;
        for (int i = idx; i < json.length(); i++) {
            char c = json.charAt(i);
            if (escaped) {
                if (c == 'n') content.append('\n');
                else if (c == 't') content.append('\t');
                else if (c == 'r') content.append('\r');
                else if (c == '\\') content.append('\\');
                else if (c == '"') content.append('"');
                else content.append(c);
                escaped = false;
            } else if (c == '\\') {
                escaped = true;
            } else if (c == '"') {
                break;
            } else {
                content.append(c);
            }
        }
        return content.toString().trim();
    }

    // ─────────────────────────────────────────────────────────────
    // Simple JSON parser — enough for our structured output needs
    // ─────────────────────────────────────────────────────────────

    static class JsonValue {
        String stringVal;
        Number numberVal;
        List<JsonValue> arrayVal;
        Map<String, JsonValue> objectVal;
        boolean isArray, isObject, isString, isNumber;

        static JsonValue of(String s) { JsonValue v = new JsonValue(); v.stringVal = s; v.isString = true; return v; }
        static JsonValue of(Number n) { JsonValue v = new JsonValue(); v.numberVal = n; v.isNumber = true; return v; }
        static JsonValue array(List<JsonValue> a) { JsonValue v = new JsonValue(); v.arrayVal = a; v.isArray = true; return v; }
        static JsonValue obj(Map<String, JsonValue> o) { JsonValue v = new JsonValue(); v.objectVal = o; v.isObject = true; return v; }

        String asString() { return stringVal; }
        int asInt() { return numberVal != null ? numberVal.intValue() : 0; }
        List<JsonValue> asArray() { return arrayVal; }
        Map<String, JsonValue> asObject() { return objectVal; }
        JsonValue get(String k) { return objectVal != null ? objectVal.get(k) : null; }

        public String toString() {
            if (isString) return "\"" + stringVal + "\"";
            if (isNumber) return numberVal.toString();
            if (isArray) return arrayVal.toString();
            if (isObject) return objectVal.toString();
            return "null";
        }
    }

    static class JsonParser {
        String input;
        int pos;

        JsonParser(String input) { this.input = input.trim(); }

        JsonValue parse() {
            if (pos >= input.length()) return null;
            char c = input.charAt(pos);
            if (c == '{') return JsonValue.obj(parseObject());
            if (c == '[') return JsonValue.array(parseArray());
            if (c == '"') return JsonValue.of(parseString());
            return parseNumberOrKeyword();
        }

        Map<String, JsonValue> parseObject() {
            Map<String, JsonValue> map = new LinkedHashMap<>();
            pos++; // skip {
            skipSpace();
            if (pos < input.length() && input.charAt(pos) == '}') { pos++; return map; }
            while (pos < input.length()) {
                skipSpace();
                if (pos >= input.length() || input.charAt(pos) == '}') { pos++; break; }
                String key = parseString();
                skipSpace();
                if (pos < input.length() && input.charAt(pos) == ':') pos++;
                skipSpace();
                JsonValue val = parse();
                map.put(key, val);
                skipSpace();
                if (pos < input.length() && input.charAt(pos) == ',') pos++;
                else if (pos < input.length() && input.charAt(pos) == '}') { pos++; break; }
            }
            return map;
        }

        List<JsonValue> parseArray() {
            List<JsonValue> list = new ArrayList<>();
            pos++; // skip [
            skipSpace();
            if (pos < input.length() && input.charAt(pos) == ']') { pos++; return list; }
            while (pos < input.length()) {
                list.add(parse());
                skipSpace();
                if (pos < input.length() && input.charAt(pos) == ',') pos++;
                else if (pos < input.length() && input.charAt(pos) == ']') { pos++; break; }
                skipSpace();
            }
            return list;
        }

        String parseString() {
            StringBuilder sb = new StringBuilder();
            pos++; // skip opening "
            while (pos < input.length()) {
                char c = input.charAt(pos);
                if (c == '\\') {
                    pos++;
                    if (pos < input.length()) {
                        char n = input.charAt(pos);
                        if (n == 'n') sb.append('\n');
                        else if (n == 't') sb.append('\t');
                        else if (n == 'r') sb.append('\r');
                        else if (n == '"') sb.append('"');
                        else if (n == '\\') sb.append('\\');
                        else sb.append(n);
                    }
                } else if (c == '"') {
                    pos++;
                    break;
                } else {
                    sb.append(c);
                }
                pos++;
            }
            return sb.toString();
        }

        JsonValue parseNumberOrKeyword() {
            StringBuilder sb = new StringBuilder();
            while (pos < input.length()) {
                char c = input.charAt(pos);
                if (Character.isDigit(c) || c == '-' || c == '.' || c == 'e' || c == 'E' || c == '+') {
                    sb.append(c);
                    pos++;
                } else break;
            }
            String s = sb.toString().trim();
            if (!s.isEmpty()) {
                if (s.contains(".") || s.contains("e") || s.contains("E"))
                    return JsonValue.of(Double.parseDouble(s));
                return JsonValue.of(Integer.parseInt(s));
            }
            // keywords: true, false, null
            if (input.startsWith("true", pos)) { pos += 4; return JsonValue.of(1); }
            if (input.startsWith("false", pos)) { pos += 5; return JsonValue.of(0); }
            if (input.startsWith("null", pos)) { pos += 4; return JsonValue.of(""); }
            return JsonValue.of("");
        }

        void skipSpace() {
            while (pos < input.length() && Character.isWhitespace(input.charAt(pos))) pos++;
        }
    }

    static JsonValue parseJson(String json) {
        return new JsonParser(json).parse();
    }

    // ─────────────────────────────────────────────────────────────
    // Convenience: extract Java code blocks from LLM response
    // ─────────────────────────────────────────────────────────────

    static List<String> extractJavaCodeBlocks(String response) {
        List<String> blocks = new ArrayList<>();
        String marker = "```java";
        int idx = 0;
        while (true) {
            int si = response.indexOf(marker, idx);
            if (si < 0) break;
            si += marker.length();
            // Skip past newline after ```java
            while (si < response.length() && (response.charAt(si) == '\n' || response.charAt(si) == '\r')) si++;
            int ei = response.indexOf("```", si);
            if (ei < 0) break;
            blocks.add(response.substring(si, ei).trim());
            idx = ei + 3;
        }
        return blocks;
    }
}
