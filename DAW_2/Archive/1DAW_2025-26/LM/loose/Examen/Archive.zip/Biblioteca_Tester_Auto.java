public class Biblioteca_Tester_Auto {

    public static void main(String[] args) {
        Biblioteca biblioteca = new Biblioteca();

        System.out.println("=== Auto-generated tester for Biblioteca ===");
        System.out.println("Empty: " + biblioteca);

        // ---- add items ----
        biblioteca.anyadirLibro(new Libro(1, "item1_titulo", "item1_autor", "item1_isbn"));
        biblioteca.anyadirLibro(new Libro(2, "item2_titulo", "item2_autor", "item2_isbn"));
        biblioteca.anyadirLibro(new Libro(3, "item3_titulo", "item3_autor", "item3_isbn"));
        System.out.println("After add 3: " + biblioteca);
        System.out.println("Searching...");
        System.out.println("buscarPorIsbn(1): " + biblioteca.buscarPorIsbn(1));
        System.out.println("buscarPorIsbn(99): " + biblioteca.buscarPorIsbn(99));
        System.out.println("Removing...");
        biblioteca.eliminarLibroPorIsbn("item1_libros");
        System.out.println("After remove: " + biblioteca);
        System.out.println("Counts...");
        System.out.println("\nUsing Iterator:");
        java.util.Iterator<Libro> it = java.util.Arrays.asList(new Libro[0]).iterator(); // placeholder
        System.out.println("=== End ===");
    }
}