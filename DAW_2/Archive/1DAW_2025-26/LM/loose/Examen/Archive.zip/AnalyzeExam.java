import java.util.*;

public class AnalyzeExam {
    public static void main(String[] args) throws Exception {
        String examText = "(4 puntos) Implementa las siguientes clases PlazaAparcamiento con los siguientes atributos : int numero → número de la plaza boolean ocupada → indica si la plaza está ocupada o no String matriculaVehiculo → matrícula del vehículo estacionado (si está ocupada) Métodos : Constructor por defecto (número = 0, no ocupada) Constructor con todos los parámetros. Método toString(). Getters y Setters de todos los atributos, menos de ocupada. boolean estaOcupada() void aparcarVehiculo(String matricula) → Marca como ocupada y guarda la matrícula. void liberarPlaza() → Marca como libre y borra la matrícula. En el método main(), crea dos objetos : uno con el constructor por defecto y otro con el constructor con parámetros, y utiliza todos los métodos al menos una vez. b. Clase Aparcamiento. Representa un conjunto de plazas. Atributos : private ArrayList PlazaAparcamiento plazas; Métodos : Constructor que cree un aparcamiento vacío. void añadirPlaza(PlazaAparcamiento p) PlazaAparcamiento buscarPlaza(int numero) int plazasLibres() int plazasOcupadas() boolean aparcarVehiculo(String matricula) Aparca el vehículo en la primera plaza libre. Devuelve true si ha podido aparcarlo. void liberarVehiculo(String matricula) Libera la plaza ocupada por ese vehículo. String toString() Método main Crear un aparcamiento con al menos 5 plazas. Aparcar varios vehículos. Liberar uno de ellos. Mostrar cuántas plazas libres y ocupadas hay. Mostrar toda la información utilizando un Iterator . (4 puntos) Una Biblioteca es una lista de libros (objetos de la clase Libro). Clase Libro: Atributos: String titulo String autor String isbn Métodos: Constructor con todos los parámetros. Getters para titulo e isbn. Setters para titulo y autor Método toString(). Clase Biblioteca: Atributos: ArrayList Libro libros Métodos: Constructor (crea una biblioteca vacía). void añadirLibro(Libro l) → añade un libro nuevo. Siempre añadiremos el libro, pero si ya hay uno con ese ISBN sacaremos un mensaje por pantalla advirtiéndolo. Libro buscarPorIsbn(String isbn) → devuelve los libros con ese isbn o null si no lo encuentra. void eliminarLibroPorIsbn(String isbn) → elimina todos los libros que tengan ese ISBN. toString() → devuelve una cadena con la información de todos los libros, separados por comas. Implementa un main que verifique que todas las operaciones funcionan correctamente. (2 puntos) Gestión de edades. Crea un programa que: Declare una variable Integer llamada edad con valor 25 (con y sin autoboxing) Convierta la cadena 30 a un objeto Integer. Calcule la suma de ambas edades (con y sin autoboxing) Muestre por pantalla el valor de cada objeto Integer. Muestre por pantalla la suma total. Pregunta teórica. Indica un caso en el que sea necesario utilizar una clase envoltorio en lugar de un tipo primitivo.";
        
        OpenRouterClient client = new OpenRouterClient(
            "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"
        );
        
        String prompt = "Analiza este texto de examen de Java y extrae la información ESTRUCTURADA de cada clase. " +
            "Para cada clase, indica: nombre, tipo (ENTITY/CONTAINER), lista de campos (tipo, nombre), " +
            "lista de métodos (returnType, nombre, parametros), capacidades (constructor por defecto, " +
            "constructor con parametros, getters, setters, toString, main), y relaciones (one-to-many). " +
            "Devuelve SOLO un JSON válido con esta estructura:\n" +
            "{\"classes\":[{\"name\":\"...\",\"role\":\"ENTITY|CONTAINER\",\"fields\":[{\"type\":\"...\",\"name\":\"...\"}]," +
            "\"methods\":[{\"ret\":\"...\",\"name\":\"...\",\"params\":[{\"type\":\"...\",\"name\":\"...\"}]}]," +
            "\"capabilities\":[\"DEFAULT_CTOR\",\"ALL_ARGS_CTOR\",\"TO_STRING\",\"GETTERS\",\"SETTERS\"]," +
            "\"getterExclude\":[\"campo\"],\"setterExclude\":[\"campo\"],\"hasMain\":true,\"containerOf\":\"...\"}]}\n\n" +
            "Texto:\n" + examText;
        
        System.out.println("Enviando consulta al LLM...");
        String resp = client.chat("Eres un analizador de código Java experto. Devuelve solo JSON.", prompt);
        System.out.println("=== LLM RESPONSE ===");
        System.out.println(resp);
        System.out.println("=== END ===");
    }
}
