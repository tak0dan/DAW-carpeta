package Examen;

public class Aparcamiento_Tester {

    public static void main(String[] args) {
        Aparcamiento ap = new Aparcamiento();

        ap.anyadirPlaza(new PlazaAparcamiento(1, false, null));
        ap.anyadirPlaza(new PlazaAparcamiento(2, false, null));
        ap.anyadirPlaza(new PlazaAparcamiento(3, true, "1111AAA"));
        ap.anyadirPlaza(new PlazaAparcamiento(4, false, null));
        ap.anyadirPlaza(new PlazaAparcamiento(5, true, "2222BBB"));

        System.out.println("Ocupadas: " + ap.plazasOcupadas());
        System.out.println("Libres: " + ap.plazasLibres());
        System.out.println(ap);

        System.out.println("\nAparcando vehiculos...");
        ap.aparcarVehiculo("3333CCC");
        ap.aparcarVehiculo("4444DDD");
        ap.aparcarVehiculo("5555EEE");

        System.out.println("Ocupadas: " + ap.plazasOcupadas());
        System.out.println("Libres: " + ap.plazasLibres());
        System.out.println(ap);

        System.out.println("\nLiberando vehiculo 1111AAA...");
        ap.liberarVehiculo("1111AAA");

        System.out.println("Ocupadas: " + ap.plazasOcupadas());
        System.out.println("Libres: " + ap.plazasLibres());
        System.out.println(ap);

        System.out.println("\nBuscando plaza numero 3: " + ap.buscarPlaza(3));
        System.out.println("Buscando plaza numero 99: " + ap.buscarPlaza(99));
    }
}
