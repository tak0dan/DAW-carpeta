import java.net.URI;
import java.net.http.*;
import java.time.Duration;
public class ListModels2 {
    public static void main(String[] args) throws Exception {
        HttpClient client = HttpClient.newHttpClient();
        HttpRequest req = HttpRequest.newBuilder()
            .uri(URI.create("https://openrouter.ai/api/v1/models"))
            .timeout(Duration.ofSeconds(30))
            .GET().build();
        HttpResponse<String> resp = client.send(req, HttpResponse.BodyHandlers.ofString());
        String body = resp.body();
        // Find all "id" fields
        int idx = 0;
        while (true) {
            int idPos = body.indexOf("\"id\":", idx);
            if (idPos < 0) break;
            int start = body.indexOf('"', idPos + 5) + 1;
            int end = body.indexOf('"', start);
            if (start > 0 && end > start) {
                String id = body.substring(start, end);
                // Check surrounding context for "free"
                int ctxStart = Math.max(0, idPos - 200);
                int ctxEnd = Math.min(body.length(), end + 200);
                String ctx = body.substring(ctxStart, ctxEnd);
                if (ctx.toLowerCase().contains("free")) {
                    System.out.println(id + " (free)");
                }
            }
            idx = end + 1;
            if (idx > body.length()) break;
        }
    }
}
