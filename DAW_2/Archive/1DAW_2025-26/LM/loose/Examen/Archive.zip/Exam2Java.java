import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.*;
import java.security.spec.*;
import java.util.*;
import java.util.regex.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import javax.crypto.*;
import javax.crypto.spec.*;
import javax.xml.parsers.*;
import org.w3c.dom.*;
import org.xml.sax.InputSource;

public class Exam2Java {

    static final Set<String> PRIMITIVE_TYPES = new HashSet<>(Arrays.asList(
        "int","Integer","double","Double","boolean","Boolean","String",
        "float","long","char","byte","short","void"));

    // ─────────────────────────────────────────────────────────────────────
    // 1. Knowledge Graph
    // ─────────────────────────────────────────────────────────────────────

    static class KGNode {
        String id;
        KGNodeType type;
        Map<String, Object> attrs = new HashMap<>();

        KGNode(String id, KGNodeType type) { this.id = id; this.type = type; }
        KGNode with(String k, Object v) { attrs.put(k, v); return this; }
        String s(String k) { Object v = attrs.get(k); return v == null ? "" : (String)v; }
        int i(String k) { Object v = attrs.get(k); return v instanceof Number ? ((Number)v).intValue() : 0; }
        @SuppressWarnings("unchecked") Set<String> ss(String k) {
            Object v = attrs.get(k); return v instanceof Set ? (Set<String>)v : new HashSet<>();
        }
    }

    enum KGNodeType { CLASS, FIELD, METHOD, RELATIONSHIP, MAIN }

    enum RelationType { ONE_TO_MANY, ONE_TO_ONE, REFERENCE }

    static class KGRelation {
        String from, to, viaField;
        RelationType type;
        double confidence;
    }

    static class KnowledgeGraph {
        Map<String, KGNode> nodes = new LinkedHashMap<>();
        List<KGRelation> relations = new ArrayList<>();
        List<String> classOrder = new ArrayList<>();

        KGNode node(String id, KGNodeType type) {
            return nodes.computeIfAbsent(id, k -> { KGNode n = new KGNode(k, type); return n; });
        }

        void addClass(String name) {
            if (!nodes.containsKey(name)) {
                nodes.put(name, new KGNode(name, KGNodeType.CLASS));
                classOrder.add(name);
            }
        }

        void addField(String cls, String type, String name) {
            String fid = cls + "." + name;
            KGNode fn = node(fid, KGNodeType.FIELD).with("type", type).with("owner", cls);
            if (type.startsWith("ArrayList<")) {
                String inner = type.replace("ArrayList<", "").replace(">", "").trim();
                if (nodes.containsKey(inner) || Character.isUpperCase(inner.charAt(0))) {
                    KGRelation r = new KGRelation();
                    r.from = cls; r.to = inner; r.viaField = name;
                    r.type = RelationType.ONE_TO_MANY; r.confidence = 0.9;
                    relations.add(r);
                }
            } else if (Character.isUpperCase(type.charAt(0)) && !PRIMITIVE_TYPES.contains(type)) {
                if (nodes.containsKey(type)) {
                    KGRelation r = new KGRelation();
                    r.from = cls; r.to = type; r.viaField = name;
                    r.type = RelationType.ONE_TO_ONE; r.confidence = 0.8;
                    relations.add(r);
                }
            }
        }

        void addMethod(String cls, String ret, String name, String paramsStr) {
            String mid = cls + "." + name + "(" + paramsStr + ")";
            node(mid, KGNodeType.METHOD).with("ret", ret).with("name", name)
                .with("params", paramsStr).with("owner", cls);
        }

        void addMainDesc(String cls, String desc) {
            node(cls + ".main", KGNodeType.MAIN).with("desc", desc).with("owner", cls);
        }

        KGNode getClass(String name) { return nodes.get(name); }

        List<KGNode> getFields(String cls) {
            List<KGNode> res = new ArrayList<>();
            for (KGNode n : nodes.values())
                if (n.type == KGNodeType.FIELD && cls.equals(n.s("owner")))
                    res.add(n);
            return res;
        }

        List<KGNode> getMethods(String cls) {
            List<KGNode> res = new ArrayList<>();
            for (KGNode n : nodes.values())
                if (n.type == KGNodeType.METHOD && cls.equals(n.s("owner")))
                    res.add(n);
            return res;
        }

        String getMainDesc(String cls) {
            KGNode n = nodes.get(cls + ".main");
            return n == null ? "" : n.s("desc");
        }

        boolean hasMain(String cls) { return nodes.containsKey(cls + ".main"); }

        List<KGRelation> getRelationsFrom(String cls) {
            List<KGRelation> res = new ArrayList<>();
            for (KGRelation r : relations) if (r.from.equals(cls)) res.add(r);
            return res;
        }

        Set<String> knownClasses() {
            Set<String> s = new LinkedHashSet<>(classOrder);
            return s;
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    // 2. Text Processing
    // ─────────────────────────────────────────────────────────────────────

    static String normalize(String t) {
        return t.toLowerCase()
            .replaceAll("á", "a").replaceAll("é", "e")
            .replaceAll("í", "i").replaceAll("ó", "o")
            .replaceAll("ú", "u").replaceAll("ü", "u")
            .replaceAll("ñ", "n")
            .replaceAll("\\s+", " ").trim();
    }

    static List<String> splitSentences(String text) {
        List<String> result = new ArrayList<>();
        String t = text.replaceAll("\\s+", " ").trim();
        // Split on . or : before section markers (Atributos, Métodos) or before any capitalized word.
        // This handles: "Clase X: Atributos: field1 field2 Métodos: method1() method2()" → separate fragments.
        String[] parts = t.split("(?<![Nnº])(?:\\.|:)\\s*(?=Atributos|Métodos|atributos|métodos|Attributes|Methods|\\(\\d|[A-ZÁÉÍÓÚÑ])");
        for (String p : parts) {
            p = p.trim();
            if (!p.isEmpty()) result.add(p);
        }
        if (result.isEmpty()) result.add(t);
        return result;
    }

    static String cleanFieldDesc(String s) {
        // Remove arrow and description: "→ description" or " - description"
        return s.replaceAll("[→\\-].*", "").trim();
    }

    // ─────────────────────────────────────────────────────────────────────
    // 3. Semantic Ontology (action words, relationship verbs, etc.)
    // ─────────────────────────────────────────────────────────────────────

    static final Set<String> RELATIONSHIP_VERBS = new HashSet<>(Arrays.asList(
        "contiene", "tiene", "almacena", "gestiona", "maneja",
        "representa", "agrupa", "organiza", "mantiene",
        "contains", "has", "stores", "manages", "holds",
        "es una lista de", "es un conjunto de", "es un array de",
        "is a list of", "is a collection of", "is a set of"));

    static final Set<String> CONCEPT_MARKERS = new HashSet<>(Arrays.asList(
        "constructor", "constructor por defecto", "constructor vacio",
        "constructor sin parametros", "constructor basico",
        "constructor con todos los parametros",
        "constructor con parametros",
        "constructor que cree", "constructor crea",
        "metodo tostring", "método tostring", "tostring",
        "getters", "getter", "setters", "setter",
        "metodos de acceso", "métodos de acceso",
        "consultar atributos", "modificar atributos",
        "default constructor", "parameterless constructor",
        "all-args constructor", "all args constructor"));

    static final Map<String, String> ACTION_SYNONYMS = new LinkedHashMap<>();
    static {
        ACTION_SYNONYMS.put("search", "search");
        ACTION_SYNONYMS.put("find", "search");
        ACTION_SYNONYMS.put("locate", "search");
        ACTION_SYNONYMS.put("retrieve", "search");
        ACTION_SYNONYMS.put("lookup", "search");
        ACTION_SYNONYMS.put("obtain", "search");
        ACTION_SYNONYMS.put("buscar", "search");
        ACTION_SYNONYMS.put("localizar", "search");
        ACTION_SYNONYMS.put("obtener", "search");

        ACTION_SYNONYMS.put("add", "add");
        ACTION_SYNONYMS.put("insert", "add");
        ACTION_SYNONYMS.put("append", "add");
        ACTION_SYNONYMS.put("anadir", "add");
        ACTION_SYNONYMS.put("añadir", "add");
        ACTION_SYNONYMS.put("agregar", "add");

        ACTION_SYNONYMS.put("remove", "remove");
        ACTION_SYNONYMS.put("delete", "remove");
        ACTION_SYNONYMS.put("eliminar", "remove");
        ACTION_SYNONYMS.put("borrar", "remove");
        ACTION_SYNONYMS.put("liberar", "remove");
        ACTION_SYNONYMS.put("release", "remove");

        ACTION_SYNONYMS.put("count", "count");
        ACTION_SYNONYMS.put("total", "count");
        ACTION_SYNONYMS.put("calcular", "count");
        ACTION_SYNONYMS.put("contar", "count");

        ACTION_SYNONYMS.put("is", "check");
        ACTION_SYNONYMS.put("has", "check");
        ACTION_SYNONYMS.put("esta", "check");
        ACTION_SYNONYMS.put("tiene", "check");
    }

    // ─────────────────────────────────────────────────────────────────────
    // 4. Sentence Classification & Extraction
    // ─────────────────────────────────────────────────────────────────────

    enum SentenceRole { CLASS_HEADER, FIELD_DECL, METHOD_SIG, CONCEPT_DESC, RELATION_DESC, MAIN_DESC, OTHER }

    static class ParsedSentence {
        SentenceRole role;
        String raw;
        // Extracted data
        String className, fieldType, fieldName;
        String methodRet, methodName, methodParams;
        String conceptKeyword;
        String relationSubject, relationVerb, relationObject;
        String mainDescription;
        // Additional multi-match data
        Map<String, Object> attrs = new HashMap<>();
    }

    static ParsedSentence classifySentence(String s, Set<String> knownCls) {
        ParsedSentence ps = new ParsedSentence();
        ps.raw = s;
        String norm = normalize(s);

        // 1. Class header — check on original case string, not normalized
        Matcher m = Pattern.compile(
            "(?:Clase|clase|class|Class)\\s+(\\w+)").matcher(s);
        if (m.find()) {
            String cn = m.group(1);
            if (cn.length() > 1 && Character.isUpperCase(cn.charAt(0))) {
                ps.role = SentenceRole.CLASS_HEADER;
                ps.className = cn;
                return ps;
            }
        }

        // Collect method signatures FIRST (before MAIN_DESC check, because
        // methods like toString() may be embedded in a main description sentence)
        List<String> methodRets = new ArrayList<>();
        List<String> methodNames = new ArrayList<>();
        List<String> methodParamsList = new ArrayList<>();

        m = Pattern.compile(
            "(?:(\\w+(?:<[^>]+>)?(?:\\[\\])?)\\s+)?(\\w+)\\s*\\(([^)]*)\\)",
            Pattern.UNICODE_CHARACTER_CLASS).matcher(s);
        while (m.find()) {
            String ret = m.group(1);
            String name = m.group(2);
            String inside = m.group(3).trim();

            if (name.equals("main")) continue;

            // Always add toString/hashCode/equals regardless of return type
            if (name.equals("toString") || name.equals("ToString")
                || name.equals("hashCode") || name.equals("equals")) {
                methodRets.add(ret != null ? ret : "void");
                methodNames.add(name);
                methodParamsList.add(inside);
                continue;
            }

            if (ret != null && !ret.isEmpty()
                && (PRIMITIVE_TYPES.contains(ret) || knownCls.contains(ret)
                    || ret.equals("ArrayList") || ret.endsWith("[]"))) {
                methodRets.add(ret);
                methodNames.add(name);
                methodParamsList.add(inside);
            }
        }

        // 2. Main description (check AFTER collecting methods, so that methods
        //    in the same sentence as "main" are still captured)
        if (norm.contains("main") && (norm.contains("crea") || norm.contains("crear")
            || norm.contains("muestre") || norm.contains("mostrar")
            || norm.contains("utilizando") || norm.contains("verifique")
            || norm.contains("compruebe"))) {
            ps.role = SentenceRole.MAIN_DESC;
            ps.mainDescription = s;
            if (!methodNames.isEmpty()) {
                int last = methodNames.size() - 1;
                ps.methodRet = methodRets.get(last);
                ps.methodName = methodNames.get(last);
                ps.methodParams = methodParamsList.get(last);
                ps.attrs.put("allMethodRets", methodRets);
                ps.attrs.put("allMethodNames", methodNames);
                ps.attrs.put("allMethodParams", methodParamsList);
            }
            return ps;
        }

        // 3. Pure method signature (no main description)
        if (!methodNames.isEmpty()) {
            ps.role = SentenceRole.METHOD_SIG;
            int last = methodNames.size() - 1;
            ps.methodRet = methodRets.get(last);
            ps.methodName = methodNames.get(last);
            ps.methodParams = methodParamsList.get(last);
            ps.attrs.put("allMethodRets", methodRets);
            ps.attrs.put("allMethodNames", methodNames);
            ps.attrs.put("allMethodParams", methodParamsList);
            return ps;
        }

        // 4. Relationship description
        for (String verb : RELATIONSHIP_VERBS) {
            if (norm.contains(verb)) {
                ps.role = SentenceRole.RELATION_DESC;
                // Extract subject and object
                String[] words = norm.split("\\s+");
                for (int i = 0; i < words.length; i++) {
                    String vn = normalize(verb);
                    if (words[i].equals(vn)) {
                        // Subject is before verb
                        StringBuilder subj = new StringBuilder();
                        for (int j = i - 1; j >= 0; j--) {
                            if (Character.isUpperCase(words[j].charAt(0))) {
                                subj.insert(0, words[j]);
                                // Reconstruct original case
                                break;
                            }
                        }
                        ps.relationSubject = subj.toString();
                        ps.relationVerb = verb;
                        // Object is after verb
                        for (int j = i + 1; j < words.length; j++) {
                            if (Character.isUpperCase(words[j].charAt(0))) {
                                ps.relationObject = words[j];
                                break;
                            }
                        }
                        return ps;
                    }
                }
                ps.role = SentenceRole.RELATION_DESC;
                return ps;
            }
        }

        // 5. Concept description
        for (String keyword : CONCEPT_MARKERS) {
            if (norm.contains(keyword)) {
                ps.role = SentenceRole.CONCEPT_DESC;
                ps.conceptKeyword = keyword;
                return ps;
            }
        }
        if (norm.contains("getter") || norm.contains("setter")
            || norm.contains("get") || norm.contains("set")
            || norm.contains("acceso") || norm.contains("accessor")
            || norm.contains("mutator")) {
            ps.role = SentenceRole.CONCEPT_DESC;
            ps.conceptKeyword = norm;
            return ps;
        }

        // 6. Field declarations: TYPE NAME (possibly multiple per sentence)
        // Match patterns like "int numero", "boolean ocupada", "String titulo", "ArrayList<X> name"
        String w = "[\\p{L}0-9_]+";
        // Buffer to collect all fields; last one wins for return value, but we store all in KG
        List<String> foundFieldTypes = new ArrayList<>();
        List<String> foundFieldNames = new ArrayList<>();

        m = Pattern.compile(
            "(ArrayList\\s*<\\s*(" + w + ")\\s*>|" +
            "int|Integer|double|Double|boolean|Boolean|String|float|long|char|byte|short)" +
            "[\\s,;]+(" + w + ")", Pattern.UNICODE_CHARACTER_CLASS).matcher(s);
        while (m.find()) {
            String rawType = m.group(1);
            String innerType = m.group(2);
            String fname = m.group(3);
            if (Character.isLowerCase(fname.charAt(0)) && fname.length() > 0) {
                String ft = rawType.startsWith("ArrayList")
                    ? (innerType != null ? "ArrayList<" + innerType + ">" : "ArrayList<Object>")
                    : rawType;
                foundFieldTypes.add(ft);
                foundFieldNames.add(fname);
            }
        }

        // Alternate: ArrayList Type name (no angle brackets in text)
        m = Pattern.compile("ArrayList\\s+(" + w + ")\\s+(" + w + ")", Pattern.UNICODE_CHARACTER_CLASS).matcher(s);
        while (m.find()) {
            String inner = m.group(1);
            String fname = m.group(2);
            if (Character.isUpperCase(inner.charAt(0)) && Character.isLowerCase(fname.charAt(0))) {
                foundFieldTypes.add("ArrayList<" + inner + ">");
                foundFieldNames.add(fname);
            }
        }

        if (!foundFieldTypes.isEmpty()) {
            ps.role = SentenceRole.FIELD_DECL;
            ps.fieldType = foundFieldTypes.get(foundFieldTypes.size() - 1);
            ps.fieldName = foundFieldNames.get(foundFieldNames.size() - 1);
            ps.attrs.put("allFieldTypes", foundFieldTypes);
            ps.attrs.put("allFieldNames", foundFieldNames);
            return ps;
        }

        // 7. Concept description from "menos de" exclusion
        if (norm.contains("menos de") || norm.contains("except")) {
            ps.role = SentenceRole.CONCEPT_DESC;
            ps.conceptKeyword = norm;
            return ps;
        }

        ps.role = SentenceRole.OTHER;
        return ps;
    }

    // ─────────────────────────────────────────────────────────────────────
    // 5. Capabilities, Action Triples, IR
    // ─────────────────────────────────────────────────────────────────────

    enum CapType { CONSTRUCTOR, ACCESSOR, MUTATOR, OUTPUT, ITERATION }
    enum CapVariant { DEFAULT, ALL_ARGS, SOME_ARGS, GETTER, SETTER, TO_STRING, CLONE, EQUALS, ITERATOR }

    static class Capability {
        CapType type;
        CapVariant variant;
        Set<String> onlyGet = new HashSet<>();
        Set<String> onlySet = new HashSet<>();
        Set<String> noGS = new HashSet<>();
        Capability(CapType t, CapVariant v) { type = t; variant = v; }
    }

    enum ClassRole { UNKNOWN, ENTITY, CONTAINER, REPOSITORY, SERVICE, RELATIONSHIP_ENTITY }

    static class ActionTriple {
        String action;   // "search", "count", "add", "remove", "check"
        String target;   // entity being acted upon
        String constraint; // filter field or criteria
        String methodName;
        boolean returnsVoid;
        List<String> paramTypes = new ArrayList<>();
        List<String> paramNames = new ArrayList<>();

        String displayName() {
            String s = action;
            if (!target.isEmpty()) s += " " + target;
            if (!constraint.isEmpty()) s += " by " + constraint;
            return s;
        }
    }

    // IR
    static class IRClass {
        String name;
        ClassRole role = ClassRole.UNKNOWN;
        List<IRField> fields = new ArrayList<>();
        List<IRMethod> methods = new ArrayList<>();
        List<Capability> capabilities = new ArrayList<>();
        List<ActionTriple> actions = new ArrayList<>();
        List<Relationship> relationships = new ArrayList<>();
        boolean hasMain;
        String mainDesc = "";
        String containerOf = "";
    }

    static class IRField { String type, name;
        IRField(String t, String n) { type = t; name = n; } }

    static class IRMethod {
        String name, ret;
        List<IRField> params = new ArrayList<>();
        ActionTriple action;

        IRMethod(String n, String r) { name = n; ret = r; }
    }

    static class Relationship {
        String targetClass, viaField;
        RelationType type;
        Relationship(String t, String f, RelationType r) { targetClass = t; viaField = f; type = r; }
    }

    // ─────────────────────────────────────────────────────────────────────
    // 6. Parser: Build KG → IR
    // ─────────────────────────────────────────────────────────────────────

    static KnowledgeGraph buildGraph(String text) {
        KnowledgeGraph kg = new KnowledgeGraph();

        // First pass: find all sentences and classify them
        List<String> sentences = splitSentences(text);
        Set<String> foundClasses = new LinkedHashSet<>();

        // Phase 1: Extract class names from all sentences
        for (String s : sentences) {
            String norm = normalize(s);
            // Class header
            Matcher m = Pattern.compile("(?:clase|class)\\s+(\\w+)",
                Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CHARACTER_CLASS).matcher(norm);
            while (m.find()) {
                String cn = m.group(1);
                if (cn.length() > 1 && Character.isUpperCase(cn.charAt(0))) {
                    // Get original case
                    Matcher cm = Pattern.compile("(?:Clase|clase|class|Class)\\s+(\\w+)",
                        Pattern.UNICODE_CHARACTER_CLASS).matcher(s);
                    if (cm.find()) cn = cm.group(1);
                    foundClasses.add(cn);
                    // Also check for "siguientes clases X Y Z"
                    String[] words = norm.split("\\s+");
                    boolean inClassList = false;
                    for (int i = 0; i < words.length; i++) {
                        if (words[i].equals("clases") || words[i].equals("clase")
                            || words[i].equals("class")) {
                            inClassList = true; continue;
                        }
                        if (inClassList && words[i].length() > 1
                            && Character.isUpperCase(words[i].charAt(0))) {
                            // Find original case
                            Matcher wm = Pattern.compile("\\b([A-ZÁÉÍÓÚÑ][a-záéíóúñA-ZÁÉÍÓÚÑ0-9]+)\\b",
                                Pattern.UNICODE_CHARACTER_CLASS).matcher(s);
                            while (wm.find()) {
                                String wc = wm.group(1);
                                if (wc.equalsIgnoreCase(words[i])) {
                                    foundClasses.add(wc); break;
                                }
                            }
                        }
                    }
                }
            }
        }

        // Also look for capitalized words that could be class names
        Matcher cm = Pattern.compile("\\b([A-Z][a-zA-ZáéíóúñÁÉÍÓÚÑ]+)\\b").matcher(text);
        while (cm.find()) {
            String w = cm.group(1);
            if (w.length() > 2 && !PRIMITIVE_TYPES.contains(w)) {
                // Check if it's followed by field/method context
                int pos = cm.end();
                String rest = pos < text.length() ? text.substring(pos, Math.min(pos + 60, text.length())) : "";
                if (rest.contains("Atributos") || rest.contains("atributos")
                    || rest.contains("Métodos") || rest.contains("Metodos")
                    || rest.contains("metodos") || rest.contains("métodos")
                    || rest.contains(" atributo") || rest.contains(" metodo")
                    || rest.contains(" método")) {
                    foundClasses.add(w);
                }
            }
        }

        // Register classes
        for (String cn : foundClasses) kg.addClass(cn);

        //         Phase 2: Classify each sentence and assign to the nearest class
        String currentClass = null;
        for (int si = 0; si < sentences.size(); si++) {
            String s = sentences.get(si);
            ParsedSentence ps = classifySentence(s, kg.knownClasses());

            // Reset currentClass for non-class sections
            String sLow = s.toLowerCase();
            if (sLow.contains("gestión de edades") || sLow.contains("gestion de edades")
                || sLow.contains("pregunta teórica") || sLow.contains("pregunta teorica")) {
                currentClass = null;
            }
            // Sentences starting with "(N puntos)" and not containing "clase" are non-class
            if (currentClass != null && !sLow.contains("clase")) {
                String trimmed = s.trim();
                if (trimmed.length() > 2 && trimmed.charAt(0) == '('
                    && Character.isDigit(trimmed.charAt(1))
                    && trimmed.contains("puntos")) {
                    currentClass = null;
                }
            }

            if (ps.role == SentenceRole.CLASS_HEADER) {
                currentClass = ps.className;
                // Do NOT continue — this sentence may also contain fields/methods/concepts
            }
            if (currentClass == null) {
                // Try to find which class this belongs to
                for (String cn : kg.classOrder) {
                    if (s.contains(cn)) { currentClass = cn; break; }
                }
                if (currentClass == null) continue;
            }

            // Check if sentence mentions a different class and should switch
            for (String cn : kg.classOrder) {
                if (!cn.equals(currentClass) && s.contains(cn)
                    && (s.contains("Clase " + cn) || s.contains("clase " + cn)
                        || s.contains("Class " + cn) || s.contains("class " + cn))) {
                    // Check if we're past the current class section
                    int curIdx = kg.classOrder.indexOf(currentClass);
                    int nextIdx = kg.classOrder.indexOf(cn);
                    if (nextIdx > curIdx) {
                        currentClass = cn;
                        break;
                    }
                }
            }

            switch (ps.role) {
                case FIELD_DECL: {
                    @SuppressWarnings("unchecked")
                    List<String> allTypes = (List<String>) ps.attrs.get("allFieldTypes");
                    @SuppressWarnings("unchecked")
                    List<String> allNames = (List<String>) ps.attrs.get("allFieldNames");
                    if (allTypes != null && allNames != null) {
                        for (int fi = 0; fi < allTypes.size(); fi++)
                            kg.addField(currentClass, allTypes.get(fi), allNames.get(fi));
                    } else {
                        kg.addField(currentClass, ps.fieldType, ps.fieldName);
                    }
                    break;
                }
                case METHOD_SIG: {
                    @SuppressWarnings("unchecked")
                    List<String> allRets = (List<String>) ps.attrs.get("allMethodRets");
                    @SuppressWarnings("unchecked")
                    List<String> allNames = (List<String>) ps.attrs.get("allMethodNames");
                    @SuppressWarnings("unchecked")
                    List<String> allParams = (List<String>) ps.attrs.get("allMethodParams");
                    if (allRets != null && allNames != null) {
                        for (int mi = 0; mi < allNames.size(); mi++) {
                            String ret = mi < allRets.size() ? allRets.get(mi) : "void";
                            String nm = allNames.get(mi);
                            String pa = mi < allParams.size() ? allParams.get(mi) : "";
                            if (nm.equals("toString") || nm.equals("hashCode") || nm.equals("equals")) {
                                if (nm.equals("toString"))
                                    kg.getClass(currentClass).attrs.put("CAP:TO_STRING", "true");
                                continue;
                            }
                            kg.addMethod(currentClass, ret, nm, pa);
                        }
                    } else {
                        kg.addMethod(currentClass, ps.methodRet, ps.methodName, ps.methodParams);
                    }
                    break;
                }
                case CONCEPT_DESC: {
                    String norm = normalize(ps.raw);
                    // Constructor detection
                    if (norm.contains("constructor por defecto") || norm.contains("constructor vacio")
                        || norm.contains("constructor sin parametros") || norm.contains("constructor basico")
                        || norm.contains("constructor que cree") || norm.contains("constructor crea")
                        || norm.contains("default constructor") || norm.contains("parameterless")
                        || norm.contains("constructor (crea")) {
                        // Check for exclusion pattern in the full sentence
                        Capability cap = new Capability(CapType.CONSTRUCTOR, CapVariant.DEFAULT);
                        extractGSExclusion(s, cap);
                        // Attach to class via node attribute
                        kg.getClass(currentClass).attrs.put("CAP:DEFAULT_CTOR", "true");
                        kg.getClass(currentClass).attrs.put("CAP:DEFAULT_CTOR_EXCLUDE", cap.noGS);
                    }
                    if (norm.contains("constructor con todos los parametros")
                        || norm.contains("constructor con parametros")
                        || norm.contains("all-args") || norm.contains("all args")) {
                        kg.getClass(currentClass).attrs.put("CAP:ALL_CTOR", "true");
                    }
                    if (norm.contains("tostring") || norm.contains("metodo tostring")
                        || norm.contains("devuelve una cadena") || norm.contains("devuelve un string")) {
                        kg.getClass(currentClass).attrs.put("CAP:TO_STRING", "true");
                    }
                    // Getters/setters
                    boolean hasGetter = norm.contains("getter") || norm.contains("get");
                    boolean hasSetter = norm.contains("setter") || norm.contains("set");
                    if (hasGetter) {
                        kg.getClass(currentClass).attrs.put("CAP:HAS_GETTERS", "true");
                        // Parse specific "para X" or "de X" patterns
                        Set<String> onlyGet = new HashSet<>();
                        Set<String> connectorWords = new HashSet<>(Arrays.asList("para","de","e","y","el","la","los","las","un","una"));
                        Matcher gm = Pattern.compile("(?:getter|getters)\\s+(?:para|de)\\s+(.+?)(?:\\.|$|setter)", Pattern.CASE_INSENSITIVE).matcher(s);
                        if (gm.find()) {
                            for (String w : gm.group(1).split("[\\s,;]+")) {
                                w = w.toLowerCase().trim();
                                if (w.length() > 1 && !connectorWords.contains(w)) onlyGet.add(w);
                            }
                        }
                        if (!onlyGet.isEmpty()) kg.getClass(currentClass).attrs.put("CAP:GETTERS_FIELDS", onlyGet);
                    }
                    if (hasSetter) {
                        kg.getClass(currentClass).attrs.put("CAP:HAS_SETTERS", "true");
                        Set<String> onlySet = new HashSet<>();
                        Matcher sm = Pattern.compile("(?:setter|setters)\\s+(?:para|de)\\s+(.+?)(?:\\.|$|getter)", Pattern.CASE_INSENSITIVE).matcher(s);
                        if (sm.find()) {
                            Set<String> connectorWords = new HashSet<>(Arrays.asList("para","de","e","y","el","la","los","las","un","una"));
                            for (String w : sm.group(1).split("[\\s,;]+")) {
                                w = w.toLowerCase().trim();
                                if (w.length() > 1 && !connectorWords.contains(w)) onlySet.add(w);
                            }
                        }
                        if (!onlySet.isEmpty()) kg.getClass(currentClass).attrs.put("CAP:SETTERS_FIELDS", onlySet);
                    }
                    // Exclusions (for getters/setters)
                    if (norm.contains("menos") || norm.contains("except")) {
                        Capability exclCap = new Capability(CapType.ACCESSOR, CapVariant.GETTER);
                        extractGSExclusion(s, exclCap);
                        if (!exclCap.noGS.isEmpty()) {
                            Set<String> existing = new HashSet<>(kg.getClass(currentClass).ss("CAP:NO_GETSET"));
                            existing.addAll(exclCap.noGS);
                            kg.getClass(currentClass).attrs.put("CAP:NO_GETSET", existing);
                        }
                    }
                    break;
                }
                case RELATION_DESC:
                    // Already handled by field detection with ArrayList type
                    break;
                case MAIN_DESC: {
                    kg.addMainDesc(currentClass, ps.mainDescription);
                    @SuppressWarnings("unchecked")
                    List<String> mdNames = (List<String>) ps.attrs.get("allMethodNames");
                    if (mdNames != null && !mdNames.isEmpty()) {
                        @SuppressWarnings("unchecked")
                        List<String> mdRets = (List<String>) ps.attrs.get("allMethodRets");
                        @SuppressWarnings("unchecked")
                        List<String> mdParams = (List<String>) ps.attrs.get("allMethodParams");
                        for (int mi = 0; mi < mdNames.size(); mi++) {
                            String nm = mdNames.get(mi);
                            String ret = mi < mdRets.size() ? mdRets.get(mi) : "void";
                            String pa = mi < mdParams.size() ? mdParams.get(mi) : "";
                            if (nm.equals("toString") || nm.equals("hashCode") || nm.equals("equals")) {
                                if (nm.equals("toString"))
                                    kg.getClass(currentClass).attrs.put("CAP:TO_STRING", "true");
                                continue;
                            }
                            kg.addMethod(currentClass, ret, nm, pa);
                        }
                    }
                    break;
                }
                case OTHER:
                    // Check for field patterns not caught by classifier
                    String w2 = "[\\p{L}0-9_]+";
                    Matcher fm = Pattern.compile(
                        "(int|Integer|double|Double|boolean|Boolean|String)" +
                        "[\\s,;]+(" + w2 + ")", Pattern.UNICODE_CHARACTER_CLASS).matcher(s);
                    while (fm.find()) {
                        String ft = fm.group(1);
                        String fn = fm.group(2);
                        if (Character.isLowerCase(fn.charAt(0))) {
                            kg.addField(currentClass, ft, fn);
                        }
                    }
                    break;
            }
        }

        return kg;
    }

    @SuppressWarnings("unchecked")
    static void extractGSExclusion(String s, Capability cap) {
        Matcher em = Pattern.compile("menos\\s+de\\s+(\\w+)", Pattern.CASE_INSENSITIVE).matcher(s);
        while (em.find()) {
            String excl = em.group(1).toLowerCase();
            if (excl.length() > 1) cap.noGS.add(excl);
        }
    }

    static List<IRClass> kgToIR(KnowledgeGraph kg) {
        List<IRClass> result = new ArrayList<>();
        Set<String> knownClasses = kg.knownClasses();

        for (String cn : kg.classOrder) {
            KGNode node = kg.getClass(cn);
            if (node == null) continue;

            IRClass cls = new IRClass();
            cls.name = cn;

            // Fields
            for (KGNode fn : kg.getFields(cn)) {
                cls.fields.add(new IRField(fn.s("type"), fn.id.substring(cn.length() + 1)));
            }

            // Methods
            for (KGNode mn : kg.getMethods(cn)) {
                String name = mn.s("name");
                String ret = mn.s("ret");
                String paramsStr = mn.s("params");

                if (name.equals("toString") || name.equals("ToString")) continue;

                IRMethod md = new IRMethod(name, ret);
                // Parse params
                if (!paramsStr.isEmpty()) {
                    Matcher pm = Pattern.compile("([\\p{L}0-9_]+(?:<[^>]+>)?)\\s+([\\p{L}0-9_]+)",
                        Pattern.UNICODE_CHARACTER_CLASS).matcher(paramsStr);
                    while (pm.find()) {
                        String pt = pm.group(1);
                        String pn = pm.group(2);
                        if (!pn.equals(cn)) md.params.add(new IRField(pt, pn));
                    }
                }
                cls.methods.add(md);
            }

            // Capabilities from KG node attrs
            String dc = node.s("CAP:DEFAULT_CTOR");
            if ("true".equals(dc)) {
                Capability cap = new Capability(CapType.CONSTRUCTOR, CapVariant.DEFAULT);
                Set<String> exclude = node.ss("CAP:DEFAULT_CTOR_EXCLUDE");
                cap.noGS.addAll(exclude);
                cls.capabilities.add(cap);
            }
            if ("true".equals(node.s("CAP:ALL_CTOR")))
                cls.capabilities.add(new Capability(CapType.CONSTRUCTOR, CapVariant.ALL_ARGS));
            if ("true".equals(node.s("CAP:TO_STRING")))
                cls.capabilities.add(new Capability(CapType.OUTPUT, CapVariant.TO_STRING));

            // Getters
            if ("true".equals(node.s("CAP:HAS_GETTERS"))) {
                Capability cap = new Capability(CapType.ACCESSOR, CapVariant.GETTER);
                cap.onlyGet.addAll(node.ss("CAP:GETTERS_FIELDS"));
                cap.noGS.addAll(node.ss("CAP:NO_GETSET"));
                cls.capabilities.add(cap);
            }
            // Setters
            if ("true".equals(node.s("CAP:HAS_SETTERS"))) {
                Capability cap = new Capability(CapType.MUTATOR, CapVariant.SETTER);
                cap.onlySet.addAll(node.ss("CAP:SETTERS_FIELDS"));
                cap.noGS.addAll(node.ss("CAP:NO_GETSET"));
                cls.capabilities.add(cap);
            }

            // Build action triples from method names
            for (IRMethod md : cls.methods) {
                md.action = buildAction(md, cls, kg);
                if (md.action != null) cls.actions.add(md.action);
            }

            // Relationships
            for (KGRelation r : kg.getRelationsFrom(cn)) {
                cls.relationships.add(new Relationship(r.to, r.viaField, r.type));
                if (r.type == RelationType.ONE_TO_MANY) cls.containerOf = r.to;
            }

            // Main
            cls.hasMain = kg.hasMain(cn);
            if (cls.hasMain) cls.mainDesc = kg.getMainDesc(cn);

            // Role
            cls.role = classifyClassRole(cls);

            if (!cls.fields.isEmpty() || !cls.methods.isEmpty()
                || !cls.capabilities.isEmpty())
                result.add(cls);
        }

        return result;
    }

    static ClassRole classifyClassRole(IRClass cls) {
        boolean hasContainerField = false;
        String containerTarget = "";
        for (Relationship r : cls.relationships) {
            if (r.type == RelationType.ONE_TO_MANY) { hasContainerField = true; containerTarget = r.targetClass; break; }
        }
        if (hasContainerField) return ClassRole.CONTAINER;

        boolean hasRef = false;
        for (IRField f : cls.fields)
            if (!f.type.startsWith("ArrayList") && !PRIMITIVE_TYPES.contains(f.type))
                hasRef = true;

        if (hasRef && cls.fields.size() >= 2) return ClassRole.RELATIONSHIP_ENTITY;
        if (cls.fields.size() >= 2) return ClassRole.ENTITY;
        if (!cls.fields.isEmpty()) return ClassRole.UNKNOWN;
        return ClassRole.SERVICE;
    }

    static ActionTriple buildAction(IRMethod md, IRClass cls, KnowledgeGraph kg) {
        String n = md.name.toLowerCase();
        if (n.equals("main") || n.equals(cls.name.toLowerCase())) return null;

        ActionTriple at = new ActionTriple();
        at.methodName = md.name;
        at.returnsVoid = md.ret.equals("void");

        for (IRField p : md.params) {
            at.paramTypes.add(p.type);
            at.paramNames.add(p.name);
        }

        // Find action word
        String[] words = n.split("[A-Z]");
        if (words.length > 0) {
            String firstWord = words[0].toLowerCase();
            String mapped = ACTION_SYNONYMS.get(firstWord);
            if (mapped != null) at.action = mapped;
        }

        // Also check prefixes
        if (at.action == null) {
            for (Map.Entry<String, String> e : ACTION_SYNONYMS.entrySet()) {
                if (n.startsWith(e.getKey())) { at.action = e.getValue(); break; }
            }
        }
        if (at.action == null) {
            // Check for contains
            for (Map.Entry<String, String> e : ACTION_SYNONYMS.entrySet()) {
                if (e.getKey().length() > 3 && n.contains(e.getKey())) {
                    at.action = e.getValue(); break;
                }
            }
        }
        if (at.action == null) at.action = "unknown";

        // Target: look for known class names in method name
        for (String kn : kg.knownClasses()) {
            if (!kn.equals(cls.name) && containsIgnoreCase(md.name, kn)) {
                at.target = kn; break;
            }
        }
        // Constraint: look for "By" + field name pattern
        Matcher bm = Pattern.compile("[Bb]y\\s+(\\w+)").matcher(md.name);
        if (bm.find()) at.constraint = bm.group(1);
        // Spanish: "Por" + field
        bm = Pattern.compile("[Pp]or\\s+(\\w+)").matcher(md.name);
        if (bm.find() && at.constraint.isEmpty()) at.constraint = bm.group(1);

        return at;
    }

    static boolean containsIgnoreCase(String s, String sub) {
        return s.toLowerCase().contains(sub.toLowerCase());
    }

    // ─────────────────────────────────────────────────────────────────────
    // 7. Code Generator
    // ─────────────────────────────────────────────────────────────────────

    static String cap(String s) {
        return s.isEmpty() ? s : Character.toUpperCase(s.charAt(0)) + s.substring(1);
    }

    static boolean hasCapability(List<Capability> caps, CapType type, CapVariant variant) {
        for (Capability c : caps) if (c.type == type && c.variant == variant) return true;
        return false;
    }

    static Capability getCapability(List<Capability> caps, CapType type, CapVariant variant) {
        for (Capability c : caps) if (c.type == type && c.variant == variant) return c;
        return null;
    }

    static String generate(IRClass cls) {
        StringBuilder out = new StringBuilder();
        boolean hasAL = cls.fields.stream().anyMatch(f -> f.type.startsWith("ArrayList"));
        if (hasAL) {
            out.append("import java.util.ArrayList;\n");
            out.append("import java.util.Iterator;\n");
        }
        out.append("\npublic class ").append(cls.name).append(" {\n\n");

        for (IRField f : cls.fields)
            out.append("    private ").append(f.type).append(" ").append(f.name).append(";\n");
        if (!cls.fields.isEmpty()) out.append("\n");

        // Default constructor from capability
        if (hasCapability(cls.capabilities, CapType.CONSTRUCTOR, CapVariant.DEFAULT)) {
            out.append("    public ").append(cls.name).append("() {\n");
            for (IRField f : cls.fields) {
                if (f.type.startsWith("ArrayList"))
                    out.append("        this.").append(f.name).append(" = new ArrayList<>();\n");
                else if (f.type.equals("int") || f.type.equals("Integer"))
                    out.append("        this.").append(f.name).append(" = 0;\n");
                else if (f.type.equals("double") || f.type.equals("Double"))
                    out.append("        this.").append(f.name).append(" = 0.0;\n");
                else if (f.type.equals("boolean") || f.type.equals("Boolean"))
                    out.append("        this.").append(f.name).append(" = false;\n");
                else
                    out.append("        this.").append(f.name).append(" = null;\n");
            }
            out.append("    }\n\n");
        }

        // All-args constructor from capability
        if (hasCapability(cls.capabilities, CapType.CONSTRUCTOR, CapVariant.ALL_ARGS)
            && !cls.fields.isEmpty()) {
            List<String> ps = new ArrayList<>();
            for (IRField f : cls.fields) ps.add(f.type + " " + f.name);
            out.append("    public ").append(cls.name).append("(")
               .append(String.join(", ", ps)).append(") {\n");
            for (IRField f : cls.fields)
                out.append("        this.").append(f.name).append(" = ").append(f.name).append(";\n");
            out.append("    }\n\n");
        }

        // Getters/setters from capabilities
        Capability getCap = getCapability(cls.capabilities, CapType.ACCESSOR, CapVariant.GETTER);
        Capability setCap = getCapability(cls.capabilities, CapType.MUTATOR, CapVariant.SETTER);
        boolean hasGS = getCap != null || setCap != null;
        Set<String> noGS = new HashSet<>();
        if (getCap != null) noGS.addAll(getCap.noGS);
        if (setCap != null) noGS.addAll(setCap.noGS);

        // Sanity: if onlyGet/onlySet specifies field names but none match actual fields,
        // treat as "get/set all" (bogus regex extraction from "todos los atributos" etc.)
        if (getCap != null && !getCap.onlyGet.isEmpty()) {
            boolean anyMatch = cls.fields.stream().anyMatch(f -> getCap.onlyGet.contains(f.name.toLowerCase()));
            if (!anyMatch) getCap.onlyGet.clear();
        }
        if (setCap != null && !setCap.onlySet.isEmpty()) {
            boolean anyMatch = cls.fields.stream().anyMatch(f -> setCap.onlySet.contains(f.name.toLowerCase()));
            if (!anyMatch) setCap.onlySet.clear();
        }

        boolean wantAllGet = getCap != null && getCap.onlyGet.isEmpty();
        boolean wantAllSet = setCap != null && setCap.onlySet.isEmpty();

        for (IRField f : cls.fields) {
            if (f.type.startsWith("ArrayList")) continue;
            String fnL = f.name.toLowerCase();
            if (noGS.contains(fnL)) continue;
            boolean isBool = f.type.equals("boolean") || f.type.equals("Boolean");
            String prefix = isBool ? "is" : "get";

            boolean doGet = wantAllGet || (getCap != null && getCap.onlyGet.contains(fnL));
            boolean doSet = wantAllSet || (setCap != null && setCap.onlySet.contains(fnL));
            if (getCap != null && !getCap.onlyGet.isEmpty()) doGet = getCap.onlyGet.contains(fnL);
            if (setCap != null && !setCap.onlySet.isEmpty()) doSet = setCap.onlySet.contains(fnL);

            if (doGet) {
                out.append("    public ").append(f.type).append(" ").append(prefix).append(cap(f.name)).append("() {\n");
                out.append("        return ").append(f.name).append(";\n    }\n");
            }
            if (doSet) {
                out.append("    public void set").append(cap(f.name)).append("(")
                   .append(f.type).append(" ").append(f.name).append(") {\n");
                out.append("        this.").append(f.name).append(" = ").append(f.name).append(";\n    }\n");
            }
            if (doGet || doSet) out.append("\n");
        }

        // toString from capability
        if (hasCapability(cls.capabilities, CapType.OUTPUT, CapVariant.TO_STRING)
            && !cls.fields.isEmpty()) {
            out.append("    @Override\n    public String toString() {\n        return \"");
            out.append(cls.name).append(" [\"");
            for (int i = 0; i < cls.fields.size(); i++) {
                out.append(" + \"").append(cls.fields.get(i).name).append("=\" + ").append(cls.fields.get(i).name);
                if (i < cls.fields.size() - 1) out.append(" + \", \"");
            }
            out.append(" + \"]\";\n    }\n\n");
        }

        // Methods
        for (IRMethod md : cls.methods) {
            List<String> ps = new ArrayList<>();
            for (IRField p : md.params) ps.add(p.type + " " + p.name);
            out.append("    public ").append(md.ret).append(" ").append(md.name).append("(")
               .append(String.join(", ", ps)).append(") {\n");
            if (md.ret.equals("boolean") || md.ret.equals("Boolean"))
                out.append("        return false;\n");
            else if (md.ret.equals("int") || md.ret.equals("Integer"))
                out.append("        return 0;\n");
            else if (md.ret.equals("double") || md.ret.equals("Double"))
                out.append("        return 0.0;\n");
            else if (md.ret.equals("void"))
                out.append("        // TODO\n");
            else
                out.append("        return null;\n");
            out.append("    }\n\n");
        }

        out.append("}\n");
        return out.toString();
    }

    // ─────────────────────────────────────────────────────────────────────
    // 8. Tester Generator (from IR, fully generic)
    // ─────────────────────────────────────────────────────────────────────

    static String sampleVal(String type, Set<String> knownClasses, boolean first) {
        if (type.equals("int") || type.equals("Integer")) return first ? "1" : "42";
        if (type.equals("boolean") || type.equals("Boolean")) return first ? "false" : "true";
        if (type.equals("double") || type.equals("Double")) return first ? "0.0" : "3.14";
        if (type.startsWith("String")) return first ? "\"valor\"" : "\"test\"";
        if (type.startsWith("ArrayList<")) {
            String inner = type.replace("ArrayList<", "").replace(">", "").trim();
            if (knownClasses.contains(inner)) return "new " + inner + "()";
            return "new ArrayList<>()";
        }
        if (knownClasses.contains(type)) return "new " + type + "()";
        return "null";
    }

    static String getterName(IRField f) {
        boolean isBool = f.type.equals("boolean") || f.type.equals("Boolean");
        return (isBool ? "is" : "get") + cap(f.name);
    }

    static boolean hasGetterFor(IRClass cls, String fieldName) {
        String fnL = fieldName.toLowerCase();
        Capability gc = getCapability(cls.capabilities, CapType.ACCESSOR, CapVariant.GETTER);
        if (gc == null) return false;
        if (gc.noGS.contains(fnL)) return false;
        return gc.onlyGet.isEmpty() || gc.onlyGet.contains(fnL);
    }

    static String generateTester(IRClass cls, List<IRClass> allClasses) {
        Set<String> knownClasses = new HashSet<>();
        for (IRClass c : allClasses) knownClasses.add(c.name);

        if (!cls.hasMain) return "";

        StringBuilder out = new StringBuilder();
        out.append("public class ").append(cls.name).append("_Tester {\n\n");
        out.append("    public static void main(String[] args) {\n");

        if (cls.role == ClassRole.CONTAINER) {
            genContainerTester(out, cls, knownClasses, allClasses);
        } else if (cls.role == ClassRole.ENTITY || cls.role == ClassRole.RELATIONSHIP_ENTITY) {
            genEntityTester(out, cls, knownClasses);
        } else {
            genGenericTester(out, cls, knownClasses);
        }

        out.append("    }\n}\n");
        return out.toString();
    }

    static void genEntityTester(StringBuilder out, IRClass cls, Set<String> knownClasses) {
        if (hasCapability(cls.capabilities, CapType.CONSTRUCTOR, CapVariant.DEFAULT)) {
            out.append("        ").append(cls.name).append(" e1 = new ").append(cls.name).append("();\n");
            out.append("        System.out.println(\"Default: \" + e1);\n\n");
        }

        if (hasCapability(cls.capabilities, CapType.CONSTRUCTOR, CapVariant.ALL_ARGS)
            && !cls.fields.isEmpty()) {
            List<String> args = new ArrayList<>();
            for (IRField f : cls.fields) args.add(sampleVal(f.type, knownClasses, true));
            out.append("        ").append(cls.name).append(" e2 = new ").append(cls.name).append("(")
               .append(String.join(", ", args)).append(");\n");
            out.append("        System.out.println(\"Parametrized: \" + e2);\n\n");
        }

        String var = hasCapability(cls.capabilities, CapType.CONSTRUCTOR, CapVariant.DEFAULT) ? "e1" : "e2";

        // Call getters
        Capability gc = getCapability(cls.capabilities, CapType.ACCESSOR, CapVariant.GETTER);
        if (gc != null) {
            for (IRField f : cls.fields) {
                if (f.type.startsWith("ArrayList")) continue;
                if (gc.noGS.contains(f.name.toLowerCase())) continue;
                boolean doGet = gc.onlyGet.isEmpty() || gc.onlyGet.contains(f.name.toLowerCase());
                if (doGet) {
                    out.append("        System.out.println(\"").append(getterName(f)).append("() = \" + ")
                       .append(var).append(".").append(getterName(f)).append("());\n");
                }
            }
        }

        // Call setters
        Capability sc = getCapability(cls.capabilities, CapType.MUTATOR, CapVariant.SETTER);
        if (sc != null) {
            for (IRField f : cls.fields) {
                if (f.type.startsWith("ArrayList")) continue;
                if (sc.noGS.contains(f.name.toLowerCase())) continue;
                boolean doSet = sc.onlySet.isEmpty() || sc.onlySet.contains(f.name.toLowerCase());
                if (doSet) {
                    out.append("        ").append(var).append(".set").append(cap(f.name)).append("(")
                       .append(sampleVal(f.type, knownClasses, false)).append(");\n");
                }
            }
        }

        // Call action methods
        for (ActionTriple at : cls.actions) {
            if (at.action.equals("check") || at.action.equals("count")
                || at.action.equals("search") || at.action.equals("unknown")) {
                List<String> args = new ArrayList<>();
                for (int i = 0; i < at.paramTypes.size(); i++)
                    args.add(sampleVal(at.paramTypes.get(i), knownClasses, false));
                if (at.returnsVoid)
                    out.append("        ").append(var).append(".").append(at.methodName).append("(")
                       .append(String.join(", ", args)).append(");\n");
                else
                    out.append("        System.out.println(\"").append(at.methodName).append(" = \" + ")
                       .append(var).append(".").append(at.methodName).append("(")
                       .append(String.join(", ", args)).append("));\n");
            }
        }

        out.append("\n        System.out.println(\"Final: \" + ").append(var).append(");\n");
    }

    static void genContainerTester(StringBuilder out, IRClass cls, Set<String> knownClasses, List<IRClass> allClasses) {
        String innerType = cls.containerOf.isEmpty() ? "Item" : cls.containerOf;

        IRClass innerClass = null;
        for (IRClass c : allClasses) if (c.name.equals(innerType)) innerClass = c;

        out.append("        ").append(cls.name).append(" c = new ").append(cls.name).append("();\n\n");
        out.append("        // Añadir elementos\n");

        // Find ADD action
        ActionTriple addAction = null;
        for (ActionTriple at : cls.actions) if ("add".equals(at.action)) { addAction = at; break; }

        if (addAction != null && innerClass != null && !innerClass.fields.isEmpty()) {
            for (int i = 1; i <= 5; i++) {
                List<String> args = new ArrayList<>();
                for (IRField f : innerClass.fields) {
                    if (f.type.equals("int") || f.type.equals("Integer")) args.add(String.valueOf(i));
                    else if (f.type.equals("boolean") || f.type.equals("Boolean")) args.add(i % 2 == 0 ? "true" : "false");
                    else if (f.type.equals("double") || f.type.equals("Double")) args.add(String.valueOf(i * 1.5));
                    else if (f.type.startsWith("String")) args.add("\"item" + i + "\"");
                    else if (knownClasses.contains(f.type)) args.add("new " + f.type + "()");
                    else args.add("null");
                }
                out.append("        c.").append(addAction.methodName).append("(new ").append(innerType).append("(")
                   .append(String.join(", ", args)).append("));\n");
            }
        } else {
            out.append("        // Cannot auto-generate items\n");
        }

        out.append("\n        System.out.println(c);\n");

        // COUNT actions
        for (ActionTriple at : cls.actions) {
            if ("count".equals(at.action)) {
                out.append("        System.out.println(\"").append(at.methodName).append("() = \" + c.").append(at.methodName).append("());\n");
            }
        }

        // SEARCH actions
        for (ActionTriple at : cls.actions) {
            if ("search".equals(at.action) && !at.paramTypes.isEmpty()) {
                List<String> args = new ArrayList<>();
                for (int i = 0; i < at.paramTypes.size(); i++)
                    args.add(sampleVal(at.paramTypes.get(i), knownClasses, false));
                out.append("        System.out.println(\"").append(at.methodName).append(" = \" + c.").append(at.methodName).append("(")
                   .append(String.join(", ", args)).append("));\n");
            }
        }

        // REMOVE actions
        for (ActionTriple at : cls.actions) {
            if ("remove".equals(at.action) && !at.paramTypes.isEmpty()) {
                List<String> args = new ArrayList<>();
                for (int i = 0; i < at.paramTypes.size(); i++)
                    args.add(sampleVal(at.paramTypes.get(i), knownClasses, false));
                if (at.returnsVoid) {
                    out.append("        c.").append(at.methodName).append("(")
                       .append(String.join(", ", args)).append(");\n");
                } else {
                    out.append("        System.out.println(\"").append(at.methodName).append(" = \" + c.").append(at.methodName).append("(")
                       .append(String.join(", ", args)).append("));\n");
                }
                out.append("        System.out.println(\"After remove: \" + c);\n");
            }
        }

        out.append("\n        System.out.println(\"Final: \" + c);\n");
    }

    static void genGenericTester(StringBuilder out, IRClass cls, Set<String> knownClasses) {
        if (hasCapability(cls.capabilities, CapType.CONSTRUCTOR, CapVariant.DEFAULT)) {
            out.append("        ").append(cls.name).append(" obj = new ").append(cls.name).append("();\n");
        } else if (hasCapability(cls.capabilities, CapType.CONSTRUCTOR, CapVariant.ALL_ARGS)
            && !cls.fields.isEmpty()) {
            List<String> args = new ArrayList<>();
            for (IRField f : cls.fields) args.add(sampleVal(f.type, knownClasses, true));
            out.append("        ").append(cls.name).append(" obj = new ").append(cls.name).append("(")
               .append(String.join(", ", args)).append(");\n");
        } else {
            out.append("        // Cannot create instance — no default constructor\n");
            return;
        }

        out.append("        System.out.println(\"obj = \" + obj);\n\n");

        Capability gc = getCapability(cls.capabilities, CapType.ACCESSOR, CapVariant.GETTER);
        if (gc != null) {
            for (IRField f : cls.fields) {
                if (f.type.startsWith("ArrayList")) continue;
                if (gc.noGS.contains(f.name.toLowerCase())) continue;
                boolean doGet = gc.onlyGet.isEmpty() || gc.onlyGet.contains(f.name.toLowerCase());
                if (doGet) {
                    out.append("        System.out.println(\"").append(getterName(f)).append("() = \" + obj.")
                       .append(getterName(f)).append("());\n");
                }
            }
        }

        Capability sc = getCapability(cls.capabilities, CapType.MUTATOR, CapVariant.SETTER);
        if (sc != null) {
            for (IRField f : cls.fields) {
                if (f.type.startsWith("ArrayList")) continue;
                if (sc.noGS.contains(f.name.toLowerCase())) continue;
                boolean doSet = sc.onlySet.isEmpty() || sc.onlySet.contains(f.name.toLowerCase());
                if (doSet) {
                    out.append("        obj.set").append(cap(f.name)).append("(")
                       .append(sampleVal(f.type, knownClasses, false)).append(");\n");
                }
            }
        }

        for (ActionTriple at : cls.actions) {
            if ("unknown".equals(at.action) || at.action.isEmpty()) continue;
            List<String> args = new ArrayList<>();
            for (int i = 0; i < at.paramTypes.size(); i++)
                args.add(sampleVal(at.paramTypes.get(i), knownClasses, false));
            if (at.returnsVoid)
                out.append("        obj.").append(at.methodName).append("(")
                   .append(String.join(", ", args)).append(");\n");
            else
                out.append("        System.out.println(\"").append(at.methodName).append(" = \" + obj.").append(at.methodName).append("(")
                   .append(String.join(", ", args)).append("));\n");
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    // 9. Main Pipeline
    // ─────────────────────────────────────────────────────────────────────

    public static void main(String[] args) throws Exception {
        if (args.length < 1) {
            System.out.println("Usage: java Exam2Java <file.docx> [--password <pwd>]");
            return;
        }
        String path = args[0];
        String password = "PRG_2026";
        for (int i = 1; i < args.length; i++)
            if ("--password".equals(args[i]) && i + 1 < args.length) password = args[i + 1];

        File inputFile = new File(path);
        if (!inputFile.exists()) { System.out.println("File not found: " + path); return; }
        byte[] data = Files.readAllBytes(inputFile.toPath());

        String text;
        if (isOLE2(data)) text = decryptAndReadOLE2(data, password);
        else text = readDocxFromZip(data);

        if (text == null || text.trim().isEmpty()) {
            System.out.println("Could not extract text."); return;
        }

        // Build Knowledge Graph
        KnowledgeGraph kg = buildGraph(text);
        System.out.println("Knowledge Graph: " + kg.classOrder.size() + " classes, "
            + kg.nodes.size() + " nodes, " + kg.relations.size() + " relations");

        // Convert to IR
        List<IRClass> classes = kgToIR(kg);

        System.out.println("Found " + classes.size() + " classes:");
        for (IRClass cls : classes) {
            System.out.println("  " + cls.name + " (" + cls.role
                + ", " + cls.fields.size() + " fields, " + cls.methods.size()
                + " methods, " + cls.actions.size() + " actions"
                + (!cls.containerOf.isEmpty() ? ", contains " + cls.containerOf : "") + ")");
        }

        String outDir = inputFile.getParent();
        if (outDir == null) outDir = ".";

        int gen = 0;
        for (IRClass cls : classes) {
            Path p = Paths.get(outDir, cls.name + ".java");
            Files.writeString(p, generate(cls));
            System.out.println("  " + cls.name + ".java");
            gen++;
        }

        int tgen = 0;
        for (IRClass cls : classes) {
            String tc = generateTester(cls, classes);
            if (!tc.isEmpty()) {
                Path tp = Paths.get(outDir, cls.name + "_Tester.java");
                Files.writeString(tp, tc);
                System.out.println("  " + cls.name + "_Tester.java");
                tgen++;
            }
        }
        System.out.println("Generated " + gen + " files.");
        if (tgen > 0) System.out.println("Generated " + tgen + " testers.");
    }

    // ─────────────────────────────────────────────────────────────────────
    // 10. OLE2 + decryption (unchanged)
    // ─────────────────────────────────────────────────────────────────────

    static boolean isOLE2(byte[] d) {
        return d.length > 8 && d[0] == (byte)0xD0 && d[1] == (byte)0xCF
            && d[2] == (byte)0x11 && d[3] == (byte)0xE0;
    }

    static String decryptAndReadOLE2(byte[] data, String password) throws Exception {
        OLE2Reader ole = new OLE2Reader(data);
        byte[] encInfo = ole.readStream("EncryptionInfo");
        byte[] encPkg = ole.readStream("EncryptedPackage");
        String xml = new String(encInfo, 8, encInfo.length - 8, "UTF-8");
        Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder()
            .parse(new InputSource(new StringReader(xml)));
        NodeList keys = doc.getDocumentElement().getElementsByTagNameNS(
            "http://schemas.microsoft.com/office/2006/keyEncryptor/password", "encryptedKey");
        if (keys.getLength() == 0) return "No encryption key found";
        Element ek = (Element) keys.item(0);
        int sc = Integer.parseInt(ek.getAttribute("spinCount"));
        int kb = Integer.parseInt(ek.getAttribute("keyBits"));
        String ha = ek.getAttribute("hashAlgorithm"), ca = ek.getAttribute("cipherAlgorithm");
        String cm = ek.getAttribute("cipherChaining");
        byte[] slt = Base64.getDecoder().decode(ek.getAttribute("saltValue"));
        byte[] ev = Base64.getDecoder().decode(ek.getAttribute("encryptedVerifierHashInput"));
        byte[] evh = Base64.getDecoder().decode(ek.getAttribute("encryptedVerifierHashValue"));
        byte[] dk = pbkdf2(password.toCharArray(), slt, sc, kb / 8, ha);
        byte[] ver = aesDecrypt(ev, dk, ca, cm);
        byte[] dVh = aesDecrypt(evh, dk, ca, cm);
        Mac mac = Mac.getInstance("HmacSHA512");
        mac.init(new SecretKeySpec(ver, "HmacSHA512"));
        if (!MessageDigest.isEqual(dVh, mac.doFinal())) return "Wrong password";
        byte[] enc = new byte[encPkg.length - 8];
        System.arraycopy(encPkg, 8, enc, 0, enc.length);
        return readDocxFromZip(aesDecrypt(enc, dk, ca, cm));
    }

    static byte[] pbkdf2(char[] pwd, byte[] slt, int it, int kl, String ha) throws Exception {
        String alg = "PBKDF2WithHmac" + ha.replace("-", "");
        try {
            return SecretKeyFactory.getInstance(alg)
                .generateSecret(new PBEKeySpec(pwd, slt, it, kl * 8)).getEncoded();
        } catch (NoSuchAlgorithmException e) {
            Mac mac = Mac.getInstance("HmacSHA512");
            byte[] pw = new String(pwd).getBytes(StandardCharsets.UTF_16LE);
            int hl = mac.getMacLength(), bl = (kl + hl - 1) / hl;
            byte[] out = new byte[kl];
            for (int i = 1; i <= bl; i++) {
                mac.init(new SecretKeySpec(pw, "HmacSHA512"));
                mac.update(slt);
                byte[] u = mac.doFinal(new byte[]{(byte)(i>>24),(byte)(i>>16),(byte)(i>>8),(byte)i});
                byte[] t = u.clone();
                for (int j = 1; j < it; j++) {
                    mac.init(new SecretKeySpec(pw, "HmacSHA512"));
                    mac.update(u); u = mac.doFinal();
                    for (int k = 0; k < hl; k++) t[k] ^= u[k];
                }
                System.arraycopy(t, 0, out, (i-1)*hl, Math.min(hl, kl-(i-1)*hl));
            }
            return out;
        }
    }

    static byte[] aesDecrypt(byte[] data, byte[] key, String algo, String chain) throws Exception {
        Cipher c = Cipher.getInstance(algo + "/" + chain + "/PKCS5Padding");
        byte[] iv = new byte[16]; System.arraycopy(key, 0, iv, 0, 16);
        c.init(Cipher.DECRYPT_MODE, new SecretKeySpec(key, algo), new IvParameterSpec(iv));
        return c.doFinal(data);
    }

    static String readDocxFromZip(byte[] zipData) throws Exception {
        try (ZipInputStream zis = new ZipInputStream(new ByteArrayInputStream(zipData))) {
            ZipEntry e; byte[] buf = new byte[8192];
            while ((e = zis.getNextEntry()) != null)
                if ("word/document.xml".equals(e.getName())) {
                    ByteArrayOutputStream bos = new ByteArrayOutputStream(); int n;
                    while ((n = zis.read(buf)) != -1) bos.write(buf, 0, n);
                    return bos.toString("UTF-8")
                        .replaceAll("<[^>]+>", " ").replaceAll("&[a-z]+;", " ")
                        .replaceAll("\\s+", " ").trim();
                }
        }
        return null;
    }

    // ── Minimal OLE2 (unchanged) ────────────────────────────────────────

    static class OLE2Reader {
        byte[] d; int ss = 512; int fc, fd; int[] fat;
        OLE2Reader(byte[] data) throws IOException {
            d = data; if (readU16(32) >= 4) ss = 4096;
            fc = readS32(44); fd = readS32(48);
            fat = new int[fc * (ss / 4)];
            for (int i = 0; i < fc && i < 109; i++) {
                int s = readS32(76 + i * 4);
                if (s >= 0 && s * ss + ss <= data.length) readFAT(s, i * (ss/4));
            }
        }
        int readU16(int p) { return (d[p]&0xFF)|((d[p+1]&0xFF)<<8); }
        int readS32(int p) {
            return (d[p]&0xFF)|((d[p+1]&0xFF)<<8)|((d[p+2]&0xFF)<<16)|(d[p+3]<<24);
        }
        void readFAT(int sec, int off) {
            int b = (sec + 1) * ss;
            for (int i = 0; i < ss/4 && off+i < fat.length; i++)
                fat[off+i] = readS32(b + i*4);
        }
        byte[] readStream(String name) throws IOException {
            int ds = fd;
            while (ds >= 0 && ds != 0xFFFFFFFE) {
                int db = (ds + 1) * ss;
                for (int i = 0; i < ss / 128; i++) {
                    int o = db + i * 128;
                    if (o + 64 > d.length) break;
                    int nl = readU16(o + 64);
                    if (nl < 2 || nl > 64) continue;
                    String en = new String(d, o, nl-2, StandardCharsets.UTF_16LE);
                    if ((d[o+66]&0xFF) == 2 && en.equals(name))
                        return readChain(readS32(o+116), readS32(o+120));
                }
                ds = fat[ds];
            }
            throw new IOException("Stream not found: " + name);
        }
        byte[] readChain(int start, int size) {
            byte[] out = new byte[Math.abs(size)];
            int pos = 0, s = start;
            while (s >= 0 && s < fat.length && pos < size) {
                int cp = Math.min(ss, size - pos);
                System.arraycopy(d, (s + 1) * ss, out, pos, cp);
                pos += cp; s = fat[s];
            }
            return out;
        }
    }
}
