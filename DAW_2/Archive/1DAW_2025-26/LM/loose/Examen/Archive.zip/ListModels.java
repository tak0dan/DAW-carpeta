import java.net.URI;
import java.net.http.*;
import java.time.Duration;
public class ListModels {
    public static void main(String[] args) throws Exception {
        HttpClient client = HttpClient.newHttpClient();
        HttpRequest req = HttpRequest.newBuilder()
            .uri(URI.create("https://openrouter.ai/api/v1/models"))
            .timeout(Duration.ofSeconds(30))
            .GET().build();
        HttpResponse<String> resp = client.send(req, HttpResponse.BodyHandlers.ofString());
        // Just print model IDs that contain "free"
        String body = resp.body();
        String[] lines = body.split("\n");
        for (String l : lines) {
            if (l.contains("free") || l.contains("Free") || l.contains("FREE")) {
                // Extract the "id" field
                int idx = l.indexOf("\"id\":");
                if (idx >= 0) {
                    int start = l.indexOf('"', idx+5) + 1;
                    int end = l.indexOf('"', start);
                    if (start > 0 && end > start) {
                        String id = l.substring(start, end);
                        if (!id.isEmpty()) System.out.println(id);
                    }
                }
            }
        }
    }
}
