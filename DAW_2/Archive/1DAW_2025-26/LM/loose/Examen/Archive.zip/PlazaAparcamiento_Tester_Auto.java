public class PlazaAparcamiento_Tester_Auto {

    public static void main(String[] args) {
        System.out.println("=== Auto-generated tester for PlazaAparcamiento ===");

        // Create with default constructor
        PlazaAparcamiento plazaAparcamiento1 = new PlazaAparcamiento();
        System.out.println("Default: " + plazaAparcamiento1);
        PlazaAparcamiento plazaAparcamiento2 = new PlazaAparcamiento(1, false, "val_matriculaVehiculo");
        System.out.println("Parametrized: " + plazaAparcamiento2);
        System.out.println("estaOcupada() = " + plazaAparcamiento2.estaOcupada());
        plazaAparcamiento2.setNumero(99);
        plazaAparcamiento2.setMatriculaVehiculo(null);
        System.out.println("after set -> getNumero() = " + plazaAparcamiento2.getNumero());
        System.out.println("after set -> getMatriculaVehiculo() = " + plazaAparcamiento2.getMatriculaVehiculo());
        plazaAparcamiento2.aparcarVehiculo("arg_matricula");
        System.out.println("After aparcarVehiculo: " + plazaAparcamiento2);
        plazaAparcamiento2.liberarPlaza();
        System.out.println("After liberarPlaza: " + plazaAparcamiento2);
        System.out.println("=== End ===");
    }
}