import java.util.*;
public class TestOpenRouter {
    public static void main(String[] args) throws Exception {
        // First test: simple chat
        OpenRouterClient client = new OpenRouterClient(
            "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",
            "google/gemini-2.0-flash-lite-preview-02-05:free"
        );
        String resp = client.chat("Responde solo 'Hola Mundo' en una linea.");
        System.out.println("Test 1: " + resp);
        System.out.println("---");
        
        // Test 2: code block extraction
        String codeResp = client.chat("Genera un Hello World en Java. Usa bloque ```java.");
        System.out.println("Test 2 raw: " + codeResp);
        List<String> blocks = OpenRouterClient.extractJavaCodeBlocks(codeResp);
        System.out.println("Blocks: " + blocks.size());
        for (String b : blocks) System.out.println(b);
    }
}
