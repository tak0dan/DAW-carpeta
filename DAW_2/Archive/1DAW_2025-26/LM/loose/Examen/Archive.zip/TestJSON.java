public class TestJSON {
    public static void main(String[] args) {
        // Test JSON parser
        String json = "{\"classes\":[{\"name\":\"Test\",\"fields\":[{\"type\":\"int\",\"name\":\"x\"}],\"methods\":[{\"returnType\":\"void\",\"name\":\"foo\",\"params\":[]}]}]}";
        OpenRouterClient.JsonValue val = OpenRouterClient.parseJson(json);
        System.out.println("Parsed: " + val);
        if (val.isObject) {
            OpenRouterClient.JsonValue cls = val.get("classes");
            if (cls != null && cls.isArray && cls.asArray().size() > 0) {
                OpenRouterClient.JsonValue first = cls.asArray().get(0);
                System.out.println("Class name: " + first.get("name").asString());
            }
        }
        
        // Test extractContent
        String resp = "{\"choices\":[{\"message\":{\"content\": \"Hola mundo\"}}]}";
        System.out.println("Content: " + OpenRouterClient.extractContent(resp));
        
        // Test code block extraction
        String codeResp = "Here is the code:\n```java\npublic class Foo {}\n```\nAnd more:\n```java\npublic class Bar {}\n```";
        System.out.println("Blocks: " + OpenRouterClient.extractJavaCodeBlocks(codeResp));
        
        System.out.println("ALL TESTS PASSED");
    }
}
