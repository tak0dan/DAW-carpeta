#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
MAVEN="${MAVEN:-mvn}"
JAVA_HOME="${JAVA_HOME:-/usr/lib/jvm/java-26-openjdk}"
export JAVA_HOME

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; NC='\033[0m'
ok()   { echo -e "${GREEN}[OK]${NC} $*"; }
info() { echo -e "${CYAN}[INFO]${NC} $*"; }
warn() { echo -e "${YELLOW}[WARN]${NC} $*"; }
err()  { echo -e "${RED}[ERR]${NC} $*"; }
bail() { err "$*"; exit 1; }
check_cmd() { command -v "$1" &>/dev/null || bail "$1 no encontrado. Instálalo primero."; }
header() {
    echo ""
    echo -e "${CYAN}============================================================${NC}"
    echo -e "${CYAN}  $1${NC}"
    echo -e "${CYAN}============================================================${NC}"
    echo ""
}

echo -e "${CYAN}"
echo "  ValenbiciJDG - Lanzador secuencial completo"
echo "  ============================================"
echo -e "${NC}"

check_cmd java
check_cmd mvn

# ─── Detectar Docker Compose ──────────────────────────────────────────
DOCKER_COMPOSE=""
if command -v docker &>/dev/null; then
    if docker compose version &>/dev/null; then
        DOCKER_COMPOSE="docker compose"
    elif command -v docker-compose &>/dev/null; then
        DOCKER_COMPOSE="docker-compose"
    fi
fi
if [ -n "$DOCKER_COMPOSE" ]; then
    ok "Docker Compose disponible: $DOCKER_COMPOSE"
else
    warn "Docker Compose no disponible. Algunas funciones no se lanzarán."
    warn "  Instálalo: https://docs.docker.com/compose/install/"
    warn "  O usa: sudo apt install docker-compose-plugin"
fi

# ─── Variables de entorno para BDD ────────────────────────────────────
header "1/6  CONFIGURANDO ENTORNO"
# Puerto 3307 porque el 3306 está ocupado por MariaDB local del sistema
export VALENBICI_DB_URL="${VALENBICI_DB_URL:-jdbc:mysql://localhost:3307/valenbicibd}"
export VALENBICI_DB_USER="${VALENBICI_DB_USER:-valenbici}"
export VALENBICI_DB_PASS="${VALENBICI_DB_PASS:-valenbici123}"
ok "VALENBICI_DB_URL=$VALENBICI_DB_URL"
ok "VALENBICI_DB_USER=$VALENBICI_DB_USER"

# ─── Compilar Java ────────────────────────────────────────────────────
header "2/6  COMPILANDO PROYECTOS JAVA"
echo "Compilando ValenbiciAPI (T1)..."
(cd "$PROJECT_DIR/ValenbiciAPI" && $MAVEN compile -q)
ok "ValenbiciAPI compilado"

echo "Compilando ValenbiciAPI26T3 (T3)..."
(cd "$PROJECT_DIR/ValenbiciAPI26T3" && $MAVEN compile -q)
ok "ValenbiciAPI26T3 compilado"

# ─── Iniciar Docker (DB + Web) ────────────────────────────────────────
header "3/6  INICIANDO SERVIDORES"

if [ -n "$DOCKER_COMPOSE" ]; then
    # Remove orphan containers from previous runs
    for c in valenbici-web valenbici-db; do
        if docker ps -a --format '{{.Names}}' | grep -q "^$c$"; then
            if ! docker ps --format '{{.Names}}' | grep -q "^$c$"; then
                docker rm "$c" &>/dev/null || true
            fi
        fi
    done

    if docker ps --format '{{.Names}}' | grep -q '^valenbici-db$'; then
        ok "Contenedores Docker ya en ejecución"
    else
        (cd "$PROJECT_DIR" && $DOCKER_COMPOSE up -d --remove-orphans 2>&1 | grep -v "^$" | head -5 || true)
        ok "Contenedores lanzados con $DOCKER_COMPOSE"

        echo "Esperando a que MariaDB acepte conexiones..."
        DB_CLIENT=""
        for client in mariadb mysql; do
            if docker exec valenbici-db which "$client" &>/dev/null 2>&1; then
                DB_CLIENT="$client"
                break
            fi
        done
        if [ -z "$DB_CLIENT" ]; then
            sleep 10
        else
            for i in $(seq 1 30); do
                if docker exec valenbici-db "$DB_CLIENT" -uvalenbici -pvalenbici123 -e "SELECT 1" &>/dev/null; then
                    ok "MariaDB lista"
                    break
                fi
                if [ "$i" -eq 30 ]; then
                    warn "MariaDB no respondió a tiempo. Continuando..."
                fi
                sleep 1
            done
        fi
    fi
else
    warn "Docker Compose no disponible — omitiendo contenedores."
    warn "Para ver la web, inicia los contenedores manualmente o usa:"
    warn "  php -S localhost:8080 -t miWeb"
fi

# ─── Ejecutar consola Java (T1) ───────────────────────────────────────
header "4/6  EJECUTANDO CONSOLA ValenbiciAPI (T1)"
echo -n "Número de estaciones a mostrar (Enter = 5, * = todas): "
read -r num
num="${num:-5}"
echo ""
(cd "$PROJECT_DIR/ValenbiciAPI" && $MAVEN exec:java -Dexec.args="$num")
ok "ValenbiciAPI finalizado"

# ─── Lanzar JFrame (T3) ──────────────────────────────────────────────
header "5/6  LANZANDO JFRAME ValenbiciAPI26T3 (T3)"
warn "Se abrirá una ventana gráfica. Ciérrala para continuar."
echo ""
(cd "$PROJECT_DIR/ValenbiciAPI26T3" && $MAVEN exec:java)
ok "JFrame cerrado"

# ─── Mostrar accesos web ─────────────────────────────────────────────
header "6/6  ACCESOS WEB Y RESUMEN"
echo ""
if [ -n "$DOCKER_COMPOSE" ]; then
    echo -e "  ${CYAN}Tabla (español):${NC}  http://localhost:8080/"
    echo -e "  ${CYAN}Tabla (inglés):${NC}   http://localhost:8080/?lang=en"
    echo -e "  ${CYAN}Mapa:${NC}            http://localhost:8080/mapearbicis.php"
    echo ""
    echo "Abriendo página principal en el navegador..."
    if command -v xdg-open &>/dev/null; then
        xdg-open "http://localhost:8080/" 2>/dev/null &
    elif command -v sensible-browser &>/dev/null; then
        sensible-browser "http://localhost:8080/" 2>/dev/null &
    else
        warn "No se pudo abrir el navegador automáticamente."
    fi
    echo ""
    warn "Para detener los contenedores: $DOCKER_COMPOSE down"
else
    echo -e "  ${YELLOW}Contenedores no iniciados. Para ver la web:${NC}"
    echo -e "  php -S localhost:8080 -t miWeb"
    echo -e "  ${YELLOW}y abre http://localhost:8080/ en el navegador${NC}"
fi
echo ""
ok "Compilación Java completada"
ok "Consola ValenbiciAPI ejecutada ($num estaciones)"
ok "JFrame ValenbiciAPI26T3 lanzado"
if [ -n "$DOCKER_COMPOSE" ]; then
    ok "Contenedores Docker en ejecución"
fi
echo ""
