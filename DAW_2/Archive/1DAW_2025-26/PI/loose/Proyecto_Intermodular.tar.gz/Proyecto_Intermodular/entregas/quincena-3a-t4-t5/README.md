# Quincena 3a — Tareas 4 y 5 (Lenguaje de marcas y Entornos de desarrollo)

**Período:** Desde el 18 de mayo de 2026

## Tarea 4 — Creación de una página web inicial

### Introducción
Crear el archivo `index.php` que consuma la API de Valenbisi y muestre los datos en una tabla HTML. Esta tarea no tiene entrega, pero es la base para las siguientes.

### Solución
Archivo `index.php` con:
- Conexión a la API mediante cURL
- Conversión de coordenadas UTM→GPS con función PHP pura (`epsg25830_to_wgs84`)
- Tabla HTML con todas las estaciones
- Generación de archivo `data.json` en el servidor

---

## Tarea 5 — Instalación de Docker y conexión

### Introducción
Instalar Docker, crear contenedores para la web (PHP 8 Apache) y la base de datos (MariaDB 11.4), y conectar la página web con los datos de la API.

### Solución

**docker-compose.yml:**
```yaml
services:
  web:
    image: php:8.3-apache
    ports: ["8080:80"]
    volumes: ["./miWeb:/var/www/html"]
  db:
    image: mariadb:11.4
    environment:
      MARIADB_DATABASE: valenbicibd
      MARIADB_USER: valenbici
      MARIADB_PASSWORD: valenbici123
    volumes: ["./docker/mysql/init:/docker-entrypoint-initdb.d"]
```

**Script de inicialización de BD:** `docker/mysql/init/01_historico.sql`

**Acceso web:**
- `http://localhost:8080/` — página principal con tabla de estaciones
- `http://localhost:8080/mapearbicis.php` — mapa interactivo

### Capturas requeridas
- [ ] Captura de Docker Desktop con contenedores en ejecución
- [ ] Captura de la página web básica en el navegador
- [ ] Captura de `docker ps` mostrando los contenedores

### Archivos incluidos
- `docker-compose.yml` (copia)
- `docker/mysql/init/01_historico.sql` (copia)
- `index.php` (copia base)
- `includes/valenbici.php` (copia)
