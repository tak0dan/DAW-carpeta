# Quincena 4c — Tarea 10 (IPEI)

**Período:** Desde el 25 de mayo de 2026

## Tarea 10 — Seguridad y Protección de Datos

### Introducción
Identificar riesgos de seguridad, aplicar medidas técnicas y organizativas, y documentar el plan preventivo del proyecto ValenbiciJDG según el módulo IPE I.

### Solución

**A. Identificación de riesgos (5 riesgos):**

| Riesgo | Descripción | Impacto |
|---|---|---|
| Acceso no autorizado a MySQL | Credenciales débiles o puerto 3306 expuesto | Lectura/modificación/borrado de datos |
| Pérdida de información | Fallo del servidor o borrado accidental | Pérdida del histórico completo |
| Exposición de puertos | 3306 o 8080 sin filtro de IP | Acceso externo no autorizado |
| Suplantación de usuario | Cuentas compartidas sin trazabilidad | Cambios inseguros sin responsable |
| Publicación de secretos | Contraseñas subidas al repositorio | Compromiso total de servicios |

**B. Medidas técnicas (5 medidas):**

| Medida | Implementación | Riesgo mitigado |
|---|---|---|
| Usuarios diferenciados | Root, aplicación (valenbici), solo-lectura | Acceso no autorizado |
| Reglas de red | Docker red interna + AWS Security Groups | Exposición de puertos |
| Copias de seguridad | mysqldump periódico | Pérdida de información |
| Consultas preparadas | PreparedStatement en Java | Inyección SQL |
| Variables de entorno | Credenciales por System.getenv() | Publicación de secretos |

**C. Medidas organizativas (5 medidas):**

| Medida | Implementación | Riesgo mitigado |
|---|---|---|
| No compartir contraseñas | Credenciales individuales | Suplantación y fuga |
| Asignación de responsables | 1-2 administradores del servidor | Cambios inseguros |
| Protocolo de incidencias | Documentar a quién avisar ante brechas | Respuesta lenta |
| Revisión antes de publicar | Comprobar código y capturas | Filtrado de datos sensibles |
| Trazabilidad en memoria | Registrar decisiones y riesgos | Falta de evidencia documental |

### Archivos incluidos
- `documentacion/seguridad-ipe.txt` (copia)
