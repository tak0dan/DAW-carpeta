# Entregas - Proyecto Intermodular ValenbiciJDG

Curso 2025/2026 — 1º DAW — IES Juan de Garay

Estructura de entregas organizada por quincenas y tareas.

| Tarea | Quincena | Contenido |
|---|---|---|
| [T1 + T2](quincena-1-t1-t2/) | 20 Mar - 30 Mar | Proyecto Java ValenbiciAPI + pom.xml |
| [T3](quincena-2-t3/) | 31 Mar - 13 Abr | JFrame + MySQL + conversión coordenadas |
| [T4 + T5](quincena-3a-t4-t5/) | 18 May | Página web básica + Docker |
| [T6 + T7](quincena-3b-t6-t7/) | 18 May (cont.) | CSS + botón + mapa Leaflet |
| [T8 - AWS](quincena-4a-t8/) | 25 May | Base de datos en AWS RDS |
| [T9 - Inglés](quincena-4b-t9/) | 25 May | Web bilingüe + glosario |
| [T10 - IPEI](quincena-4c-t10/) | 25 May | Seguridad y prevención |
| [T11 - Memoria](tarea-11-memoria/) | Final | Memoria final del proyecto |
