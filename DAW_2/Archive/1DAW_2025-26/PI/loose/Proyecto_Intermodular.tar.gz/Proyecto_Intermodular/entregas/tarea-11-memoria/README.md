# Tarea 11 — Memoria Final

**Entrega:** Final del proyecto

## Memoria del proyecto ValenbiciJDG

La memoria completa del proyecto se encuentra en:

📄 [`../../documentacion/memoria.html`](../../documentacion/memoria.html)

### Estructura de la memoria

| Sección | Contenido |
|---|---|
| Portada | Título, autor, curso, logotipo Conselleria |
| Índice | Enlaces a todas las secciones con número de página |
| T1 | Configuración del proyecto y procesamiento JSON |
| T2 | Dependencias Maven |
| T3 | JFrame, MySQL y actualización en BDD |
| T5 | Docker y despliegue |
| T6/T7 | Web mejorada y mapa |
| T8 | BBDD en AWS |
| T9 | Inglés (páginas bilingües, resumen, glosario) |
| T10 | IPE - Seguridad y protección de datos |
| Instrucciones de uso | Enlace a instrucciones.md |
| Mapa del proyecto | Enlace a mapa-proyecto.html |
| Bibliografía | Fuentes y referencias |

### Documentación adicional

| Archivo | Descripción |
|---|---|
| [`../../documentacion/instrucciones.md`](../../documentacion/instrucciones.md) | Instrucciones detalladas de todos los módulos |
| [`../../documentacion/mapa-proyecto.html`](../../documentacion/mapa-proyecto.html) | Mapa visual de arquitectura y flujo de datos |
| [`../../documentacion/glosario.txt`](../../documentacion/glosario.txt) | Glosario técnico (inglés) |
| [`../../documentacion/resumen-ingles.txt`](../../documentacion/resumen-ingles.txt) | Resumen del proyecto en inglés |
| [`../../documentacion/seguridad-ipe.txt`](../../documentacion/seguridad-ipe.txt) | Análisis IPE de riesgos y medidas |

### Requisitos de entrega
- [ ] Memoria en formato DIN A4
- [ ] Páginas numeradas
- [ ] Portada con título, autor, curso, logotipo
- [ ] Índice con títulos y números de página
- [ ] Contenido claro y concreto
- [ ] Sin faltas de ortografía
- [ ] Bibliografía ordenada alfabéticamente
