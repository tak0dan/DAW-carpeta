# Quincena 1 — Tareas 1 y 2 (Programación)

**Período:** 20 de marzo al 30 de marzo de 2026

## Tarea 1 — Crear proyecto Java ValenbiciAPI

### Introducción
Crear un proyecto Maven llamado `ValenbiciAPI` que se conecte a la API pública de Valenbisi del Ayuntamiento de Valencia, descargue los datos en formato JSON, los procese y muestre por consola la información de cada estación.

### Solución
Clase principal: `ValenbiciAPI.java` en el paquete `es.gva.edu.iesjuandegaray.bicis`.

```java
// Fragmento: conexión a la API con Apache HttpClient
private static String fetchJson(String url) throws IOException {
    try (CloseableHttpClient httpClient = HttpClients.createDefault()) {
        HttpGet request = new HttpGet(url);
        HttpResponse response = httpClient.execute(request);
        // ...
        return EntityUtils.toString(entity, StandardCharsets.UTF_8);
    }
}
```

Funcionalidad:
- Conexión HTTP GET a la API de Valenbisi
- Parseo de JSON con org.json (JSONObject / JSONArray)
- Extracción de campos: number, address, available, free, total, open, updated_at, x/y geometry
- Impresión formateada por consola
- Acepta argumento `N` para limitar el número de estaciones

### Capturas requeridas
- [ ] Captura del proyecto Maven en Eclipse (estructura)
- [ ] Captura del código ValenbiciAPI.java
- [ ] Captura del proyecto subido a GitHub

---

## Tarea 2 — Configurar el archivo pom.xml

### Introducción
Configurar el archivo `pom.xml` de Maven con las dependencias necesarias y el plugin de ejecución.

### Solución

**Dependencias añadidas:**
| Dependencia | Versión | Función |
|---|---|---|
| httpclient | 4.5.13 | Conexión HTTP con la API |
| org.json | 20210307 | Parseo de JSON |

**Plugin:**
| Plugin | Versión | Función |
|---|---|---|
| exec-maven-plugin | 3.6.3 | Ejecutar la clase principal desde CLI |

**Propiedades:**
- `maven.compiler.release`: 26
- `exec.mainClass`: es.gva.edu.iesjuandegaray.bicis.ValenbiciAPI

### Capturas requeridas
- [ ] Captura del archivo pom.xml configurado
- [ ] Captura de la salida por consola ejecutando `mvn exec:java`

---

### Archivos incluidos en esta entrega
- `ValenbiciAPI.java` (copia)
- `pom.xml` (copia)
