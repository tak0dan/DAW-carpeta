# Quincena 4b — Tarea 9 (Inglés)

**Período:** Desde el 25 de mayo de 2026

## Tarea 9 — Inglés

### Introducción
Incorporar contenido en inglés al proyecto: páginas web bilingües, glosario técnico y resumen del proyecto.

### Solución

**Apartados realizados:**

1. **Páginas web bilingües** (index.php + mapearbicis.php):
   - Botón de cambio de idioma que alterna entre español e inglés
   - Parámetro `?lang=es` o `?lang=en` en la URL
   - Todos los textos traducidos gestionados desde `valenbici_messages()`
   - Traducciones en `includes/valenbici.php` (arrays ES/EN)

2. **Glosario técnico** (`documentacion/glosario.txt`):
   - Términos: API, Available bikes, Free docks, JSON, Leaflet, Maven, MySQL, Open data, RDS, Security group, Station, WGS84
   - Definiciones en inglés

3. **Resumen en inglés** (`documentacion/resumen-ingles.txt`):
   - ~200 palabras explicando el proyecto ValenbiciJDG
   - Objetivos, funcionalidades e impacto en movilidad urbana

### Capturas requeridas
- [ ] Captura de index.php con el selector de idioma
- [ ] Captura de index.php en inglés (?lang=en)
- [ ] Captura de mapearbicis.php en inglés

### Archivos incluidos
- `includes/valenbici.php` (copia con mensajes bilingües)
- `documentacion/glosario.txt` (copia)
- `documentacion/resumen-ingles.txt` (copia)
