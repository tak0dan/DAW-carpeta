USE valenbicibd;

INSERT INTO historico (
    estacion_id,
    direccion,
    bicis_disponibles,
    anclajes_libres,
    total_puestos,
    estado_operativo,
    fecha_registro,
    ubicacion
) VALUES
    (1, 'Calle de la Paz', 12, 8, 20, TRUE, NOW(), ST_GeomFromText('POINT(-0.375657 39.469907)', 4326)),
    (8, 'Plaza del Ayuntamiento', 7, 13, 20, TRUE, NOW(), ST_GeomFromText('POINT(-0.377390 39.469750)', 4326)),
    (19, 'Estacion del Norte', 4, 16, 20, TRUE, NOW(), ST_GeomFromText('POINT(-0.377890 39.466420)', 4326));
