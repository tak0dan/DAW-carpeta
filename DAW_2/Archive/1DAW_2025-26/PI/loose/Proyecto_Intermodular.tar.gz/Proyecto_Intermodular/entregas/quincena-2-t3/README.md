# Quincena 2 — Tarea 3 (Programación con entorno gráfico y bases de datos)

**Período:** 31 de marzo al 13 de abril de 2026

## Tarea 3 — JFrame de conexión con base de datos MySQL

### Introducción
Crear un proyecto Maven llamado `ValenbiciAPI26T3` que incluya una interfaz gráfica (JFrame) para conectar con MySQL/MariaDB, descargar datos de la API de Valenbisi, crear la tabla `historico` e insertar registros con coordenadas convertidas de UTM a GPS.

### Solución

**Clases creadas:**

| Clase | Paquete | Función |
|---|---|---|
| `ConexionBDD.java` | es.gva.edu.iesjuandegaray.bicis | JFrame con botones para datos, conexión, crear tabla, añadir a BDD, limpiar |
| `DatosJSon.java` | es.gva.edu.iesjuandegaray.bicis | Descarga y parseo del JSON de la API, conversión UTM→GPS |
| `ConversionGeoLongLat.java` | es.gva.edu.iesjuandegaray.bicis | Transformación de coordenadas con librería Proj4j |

**Dependencias nuevas:**
| Dependencia | Versión |
|---|---|
| mysql-connector-j | 9.2.0 |
| proj4j | 1.4.1 |

**Interfaz del JFrame:**
- Campo de texto para número de estaciones
- Botón **Datos**: descarga de la API
- Botón **Conectar**: conexión JDBC
- Botón **Crear tabla**: DDL para `historico`
- Botón **Añadir a BDD**: inserción por lotes con PreparedStatement
- Botón **Limpiar**: limpia el área de texto
- Área de texto con JScrollPane
- Etiquetas de estado de conexión y operación

**Tabla historico:**
```sql
CREATE TABLE historico (
    id INT AUTO_INCREMENT PRIMARY KEY,
    estacion_id INT NOT NULL,
    direccion VARCHAR(255),
    bicis_disponibles INT NOT NULL,
    anclajes_libres INT NOT NULL,
    total_puestos INT NOT NULL,
    estado_operativo BOOLEAN NOT NULL,
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ubicacion POINT
);
```

**Conversión de coordenadas:**
- UTM (EPSG:25830) → WGS84 (EPSG:4326) mediante proj4j
- Si la API devuelve coordenadas en EPSG:4326, se usan directamente

### Capturas requeridas
- [ ] Captura del JFrame con los componentes
- [ ] Captura de la conexión correcta a MySQL
- [ ] Captura de los registros insertados en la tabla historico
- [ ] Captura de la conversión de coordenadas

### Archivos incluidos
- `ConexionBDD.java`, `DatosJSon.java`, `ConversionGeoLongLat.java` (copias)
- `pom.xml` (copia)
