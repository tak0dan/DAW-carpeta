# Quincena 4a — Tarea 8 (Entornos de desarrollo)

**Período:** Desde el 25 de mayo de 2026

## Tarea 8 — Mejora tu proyecto creando una base de datos en AWS

### Introducción
Desplegar una base de datos MariaDB en Amazon RDS (AWS Academy Learner Lab) y configurar el proyecto ValenbiciJDG para conectarse a ella.

### Solución

**Pasos seguidos (según anexo UD10):**

1. **Iniciar laboratorio** en AWS Academy Learner Lab
2. **Crear base de datos** RDS MariaDB en capa gratuita:
   - Identificador de instancia
   - Usuario administrador y contraseña
   - Acceso público: Sí
   - Puerto: 3306
   - Grupo de seguridad VPC
3. **Configurar grupo de seguridad**:
   - Regla de entrada para puerto 3306
   - Restringir por IP (no 0.0.0.0/0 en producción)
4. **Anotar endpoint** y puerto
5. **Crear base de datos** `valenbicibd`
6. **Importar datos de muestra** desde `aws/import-sample-data.sql`

**Conexión desde la aplicación:**
- Modificar variables de entorno `VALENBICI_DB_URL`, `VALENBICI_DB_USER`, `VALENBICI_DB_PASS`
- Endpoint de AWS en lugar de `localhost`

**Adaptación del proyecto:**
- Crear proyecto `ValenbiciAPI26T8` (copia de T3) o reutilizar T3 con variables de entorno
- Modificar credenciales para apuntar a AWS RDS
- Probar conexión con MySQL Workbench o DBeaver

### Capturas requeridas
- [ ] Captura del grupo de seguridad con reglas de entrada
- [ ] Captura del endpoint de RDS
- [ ] Captura de la conexión desde MySQL Workbench/DBeaver
- [ ] Captura del import de datos de muestra
- [ ] Captura del proyecto subido a GitHub
- [ ] Captura del archivo README.md

### Archivos incluidos
- `aws/checklist-rds.txt` (copia)
- `aws/import-sample-data.sql` (copia)
- `sql/01_create_historico.sql` (copia)
- README.md de ejemplo
