# Instrucciones del Proyecto ValenbiciJDG

> 📌 Consulta también el **[mapa del proyecto](mapa-proyecto.html)** para ver la arquitectura visual, el flujo de datos y todos los puntos clave marcados.

## Estructura del proyecto

```
Proyecto_Intermodular/
├── ValenbiciAPI/          # T1/T2 - Consola: descarga JSON de Valenbisi
│   └── src/main/java/.../ValenbiciAPI.java
├── ValenbiciAPI26T3/      # T3 - JFrame + MySQL + conversión coordenadas
│   └── src/main/java/.../ConexionBDD.java, DatosJSon.java, ConversionGeoLongLat.java
├── miWeb/                 # T6/T7/T9 - Web bilingüe PHP
│   ├── index.php          # Tabla con métricas
│   ├── mapearbicis.php    # Mapa Leaflet interactivo
│   ├── includes/valenbici.php  # Lógica compartida
│   └── styles.css
├── docker/                # T5 - Configuración Docker
│   └── mysql/init/01_historico.sql
├── sql/                   # Scripts SQL
│   ├── 01_create_historico.sql
│   └── 02_sample_data.sql
├── aws/                   # T8 - Despliegue AWS RDS
│   ├── checklist-rds.txt
│   └── import-sample-data.sql
├── documentacion/         # Documentación
│   ├── memoria.html
│   ├── mapa-proyecto.html
│   ├── instrucciones.md
│   ├── glosario.txt
│   ├── resumen-ingles.txt
│   ├── seguridad-ipe.txt
│   └── Logo_Conselleria.jpg
└── docker-compose.yml
```

## Requisitos previos

- **Java 11+** (probado con Java 26)
- **Maven 3.6+**
- **Docker** y opcionalmente **Docker Compose**
- Navegador web moderno

---

## Módulo 1: ValenbiciAPI (T1/T2) — Consola Java

### Desde terminal

```bash
# Compilar
cd ValenbiciAPI
mvn compile

# Ejecutar (N = número de estaciones a mostrar)
mvn exec:java -Dexec.args="N"

# Ejemplo: mostrar 5 estaciones
mvn exec:java -Dexec.args="5"

# Ejemplo: mostrar todas
mvn exec:java -Dexec.args="0"
```

### Desde Eclipse

1. `File > Import > Existing Maven Projects`
2. Seleccionar `ValenbiciAPI/`
3. Abrir `ValenbiciAPI.java` en `es.gva.edu.iesjuandegaray.bicis`
4. Ejecutar: botón derecho `Run As > Java Application`
5. Para pasar argumentos: `Run > Run Configurations > Arguments > Program arguments`

### Desde VSCode

1. `File > Open Folder` → seleccionar `ValenbiciAPI/`
2. Extensiones recomendadas: **Extension Pack for Java** (Microsoft)
3. Abrir `ValenbiciAPI.java`
4. `F5` o `Run > Start Debugging`
5. Para argumentos: editar `.vscode/launch.json` con `"args": ["5"]`

---

## Módulo 2: ValenbiciAPI26T3 (T3) — JFrame + MySQL

### Desde terminal

```bash
cd ValenbiciAPI26T3
mvn compile
mvn exec:java
```

Esto lanza la ventana `ConexionBDD` con los botones:
- **Datos**: descarga de la API
- **Conectar**: conexión a MySQL/MariaDB
- **Crear tabla**: crea la tabla `historico`
- **Añadir a BDD**: inserta los datos
- **Limpiar**: limpia el área de texto

### Variables de entorno (opcional)

| Variable | Valor por defecto |
|---|---|
| `VALENBICI_DB_URL` | `jdbc:mysql://localhost:3306/valenbicibd` |
| `VALENBICI_DB_USER` | `valenbici` |
| `VALENBICI_DB_PASS` | `valenbici123` |

### Desde Eclipse / VSCode

Mismos pasos que ValenbiciAPI. Configurar las variables de entorno en:
- **Eclipse**: `Run > Run Configurations > Environment`
- **VSCode**: en `.vscode/launch.json`, sección `env`

---

## Módulo 3: Web PHP (T5/T6/T7/T9) — Docker

### Con Docker Compose (recomendado)

```bash
docker compose up -d
```

### Sin Docker Compose (arranque manual)

```bash
# Crear red
docker network create valenbici-net

# Iniciar MariaDB
docker run -d \
  --name valenbici-db \
  --network valenbici-net \
  -e MARIADB_ROOT_PASSWORD=rootpass \
  -e MARIADB_DATABASE=valenbicibd \
  -e MARIADB_USER=valenbici \
  -e MARIADB_PASSWORD=valenbici123 \
  -v $(pwd)/docker/mysql/init:/docker-entrypoint-initdb.d \
  mariadb:11.4

# Iniciar PHP-Apache
docker run -d \
  --name valenbici-web \
  --network valenbici-net \
  -p 8080:80 \
  -v $(pwd)/miWeb:/var/www/html \
  php:8.3-apache

# Arreglar permisos
docker exec valenbici-web chown -R www-data:www-data /var/www/html
```

### Acceso

| Página | URL |
|---|---|
| Tabla (español) | `http://localhost:8080/` |
| Tabla (inglés) | `http://localhost:8080/?lang=en` |
| Mapa | `http://localhost:8080/mapearbicis.php` |
| Mapa (inglés) | `http://localhost:8080/mapearbicis.php?lang=en` |

---

## Módulo 4: Base de datos (MySQL/MariaDB)

### Insertar datos de ejemplo

```bash
# Dentro del contenedor Docker
docker exec -i valenbici-db mariadb -u valenbici -pvalenbici123 valenbicibd < sql/02_sample_data.sql

# Verificar
docker exec valenbici-db mariadb -u valenbici -pvalenbici123 valenbicibd -e "SELECT * FROM historico;"
```

### Desde el JFrame de Java

1. Lanzar `ValenbiciAPI26T3` con `mvn exec:java` (o desde Eclipse/VSCode)
2. Click **Conectar**
3. Click **Crear tabla**
4. Click **Datos** para descargar estaciones
5. Click **Añadir a BDD** para insertar

---

## AWS RDS (T8)

Seguir la checklist en `aws/checklist-rds.txt`. Resumen:

1. AWS Academy Learner Lab → RDS
2. Crear MariaDB (capa gratuita)
3. Configurar Security Group (puerto 3306)
4. Anotar endpoint
5. Conectar con MySQL Workbench / DBeaver
6. Ejecutar `aws/import-sample-data.sql`

---

## Notas adicionales

- **Java 26** disponible en: `/usr/lib/jvm/java-26-openjdk`
- **Maven** usado en este entorno: `/tmp/apache-maven-3.9.9/bin/mvn`
- Los datos JSON se cachean en `data.json` dentro del contenedor web
- La web cambia de idioma con `?lang=es` o `?lang=en`
