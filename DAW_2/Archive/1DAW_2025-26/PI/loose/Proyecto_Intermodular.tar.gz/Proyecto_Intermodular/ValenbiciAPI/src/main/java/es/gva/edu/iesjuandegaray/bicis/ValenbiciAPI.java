package es.gva.edu.iesjuandegaray.bicis;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;

public final class ValenbiciAPI {
    private static final String API_URL =
        "https://geoportal.valencia.es/server/rest/services/OPENDATA/Trafico/MapServer/228/query"
            + "?where=1%3D1"
            + "&outFields=*"
            + "&returnGeometry=true"
            + "&f=json";

    private static final Logger LOG = Logger.getLogger(ValenbiciAPI.class.getName());
    private static final DateTimeFormatter DT_FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    static {
        try {
            String logDir = Paths.get(System.getProperty("user.dir", "."), "logs").toString();
            java.nio.file.Files.createDirectories(Paths.get(logDir));
            FileHandler fh = new FileHandler(logDir + "/valenbiciapi.log", true);
            fh.setFormatter(new SimpleFormatter());
            fh.setLevel(Level.ALL);
            LOG.addHandler(fh);
            LOG.setLevel(Level.ALL);
            LOG.setUseParentHandlers(false);
        } catch (IOException e) {
            System.err.println("No se ha podido inicializar el log: " + e.getMessage());
        }
    }

    private ValenbiciAPI() {
    }

    public static void main(String[] args) {
        int totalEstaciones = 5;

        if (args.length > 0) {
            try {
                totalEstaciones = Math.max(1, Integer.parseInt(args[0]));
            } catch (NumberFormatException ex) {
                LOG.warning("Numero de estaciones no valido, se usaran 5.");
            }
        }

        LOG.info("=== INICIO ValenbiciAPI ===");
        LOG.info("Estaciones solicitadas: " + totalEstaciones);
        logAccion("Inicio", "Solicitadas " + totalEstaciones + " estaciones");

        try {
            String responseBody = fetchJson(API_URL);
            printStations(responseBody, totalEstaciones);
        } catch (IOException ex) {
            LOG.severe("Error al consultar la API de Valenbisi: " + ex.getMessage());
            logAccion("ERROR", ex.getMessage());
        }

        LOG.info("=== FIN ValenbiciAPI ===");
    }

    private static String fetchJson(String url) throws IOException {
        LOG.info("Consultando API: " + url);
        long inicio = System.currentTimeMillis();

        try (CloseableHttpClient httpClient = HttpClients.createDefault()) {
            HttpGet request = new HttpGet(url);
            HttpResponse response = httpClient.execute(request);
            int statusCode = response.getStatusLine().getStatusCode();
            long duracion = System.currentTimeMillis() - inicio;

            LOG.info("Respuesta HTTP " + statusCode + " (" + duracion + "ms)");

            if (statusCode != 200) {
                LOG.severe("API devolvio HTTP " + statusCode);
                throw new IOException("La API devolvio HTTP " + statusCode);
            }

            HttpEntity entity = response.getEntity();
            if (entity == null) {
                LOG.severe("API no devolvio contenido");
                throw new IOException("La API no devolvio contenido.");
            }

            String body = EntityUtils.toString(entity, StandardCharsets.UTF_8);
            LOG.info("JSON descargado: " + body.length() + " bytes");
            logAccion("API", "Descargados " + body.length() + " bytes en " + duracion + "ms");
            return body;
        }
    }

    private static void printStations(String responseBody, int totalEstaciones) {
        JSONObject root = new JSONObject(responseBody);
        JSONArray features = root.optJSONArray("features");

        if (features == null || features.length() == 0) {
            LOG.warning("No se han encontrado estaciones en la respuesta JSON.");
            System.out.println("No se han encontrado estaciones en la respuesta JSON.");
            return;
        }

        int limite = Math.min(totalEstaciones, features.length());
        LOG.info("Procesando " + limite + " de " + features.length() + " estaciones disponibles");
        System.out.println("=== RESUMEN VALENBISI ===");
        int contador = 0;

        for (int index = 0; index < limite; index++) {
            JSONObject feature = features.getJSONObject(index);
            JSONObject attributes = feature.optJSONObject("attributes");
            JSONObject geometry = feature.optJSONObject("geometry");

            if (attributes == null) {
                continue;
            }

            int number = attributes.optInt("number", -1);
            String address = attributes.optString("address", "Sin direccion");
            int available = attributes.optInt("available", 0);
            int free = attributes.optInt("free", 0);
            int total = attributes.optInt("total", available + free);
            boolean open = "T".equalsIgnoreCase(attributes.optString("open", "F"));
            String updatedAt = attributes.optString("updated_at", "Sin fecha");
            double x = geometry != null ? geometry.optDouble("x", 0.0) : 0.0;
            double y = geometry != null ? geometry.optDouble("y", 0.0) : 0.0;

            System.out.println("Estacion #" + number);
            System.out.println("  Direccion: " + address);
            System.out.println("  Bicicletas disponibles: " + available);
            System.out.println("  Anclajes libres: " + free);
            System.out.println("  Total puestos: " + total);
            System.out.println("  Estado operativo: " + (open ? "Abierta" : "Cerrada"));
            System.out.println("  Ultima actualizacion: " + updatedAt);
            System.out.println("  Coordenadas API (x/y): " + x + " / " + y);
            System.out.println();
            contador++;
        }

        LOG.info("Mostradas " + contador + " estaciones por consola");
        logAccion("Datos", "Mostradas " + contador + " estaciones");
    }

    private static void logAccion(String tipo, String detalle) {
        LOG.info("[" + tipo + "] " + detalle);
    }
}
