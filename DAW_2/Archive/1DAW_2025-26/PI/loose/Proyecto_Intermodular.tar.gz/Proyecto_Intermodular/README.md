# ValenbiciJDG

Proyecto intermodular de 1º DAW — IES Juan de Garay, curso 2025/2026.

Aplicación que consume la API pública de Valenbisi (bicicletas compartidas de Valencia), la procesa y la muestra en una interfaz Java de consola, un JFrame Swing con MySQL, y una web bilingüe con mapa Leaflet.

---

## Estructura del proyecto

| Ruta | Descripción |
|---|---|
| [`ValenbiciAPI/`](ValenbiciAPI/) | T1/T2 — Consola Java que descarga y muestra el JSON de la API |
| [`ValenbiciAPI26T3/`](ValenbiciAPI26T3/) | T3 — JFrame Swing + MySQL + conversión de coordenadas UTM a GPS |
| [`miWeb/`](miWeb/) | T5/T6/T7/T9 — Web bilingüe PHP con tabla, métricas y mapa Leaflet |
| [`docker/`](docker/) | T5 — Scripts SQL de inicialización de MariaDB |
| [`sql/`](sql/) | Scripts SQL para crear la BD y datos de ejemplo |
| [`aws/`](aws/) | T8 — Checklist y scripts para desplegar en AWS RDS |
| [`documentacion/`](documentacion/) | Memoria, instrucciones, glosario y documentación IPE |

## Documentación

| Archivo | Contenido |
|---|---|
| [`documentacion/memoria.html`](documentacion/memoria.html) | Memoria completa del proyecto (tareas T1–T10) |
| [`documentacion/mapa-proyecto.html`](documentacion/mapa-proyecto.html) | Mapa visual con arquitectura, flujo de datos y puntos clave |
| [`documentacion/instrucciones.md`](documentacion/instrucciones.md) | Instrucciones detalladas de todos los módulos |
| [`documentacion/glosario.txt`](documentacion/glosario.txt) | Glosario técnico (inglés) |
| [`documentacion/resumen-ingles.txt`](documentacion/resumen-ingles.txt) | Resumen del proyecto en inglés (~200 palabras) |
| [`documentacion/seguridad-ipe.txt`](documentacion/seguridad-ipe.txt) | Análisis IPE de riesgos y medidas preventivas |
| [`aws/checklist-rds.txt`](aws/checklist-rds.txt) | Checklist paso a paso para desplegar en AWS RDS |

## Lanzamiento rápido

```bash
# Ver todas las opciones
./valenbici.sh help

# Opción recomendada: Docker Compose
./valenbici.sh recommended

# Opción manual (sin compose)
./valenbici.sh manual

# Compilar y ejecutar ValenbiciAPI (consola)
./valenbici.sh java1 5

# Compilar y ejecutar el JFrame con MySQL
./valenbici.sh java2

# Compilar todos los proyectos Java
./valenbici.sh build

# Ver logs
./valenbici.sh logs
```

## Acceso web

| Página | URL |
|---|---|
| Tabla (español) | `http://localhost:8080/` |
| Tabla (inglés) | `http://localhost:8080/?lang=en` |
| Mapa interactivo | `http://localhost:8080/mapearbicis.php` |

## Tecnologías

- **Java 11+** con Maven, Apache HttpClient, org.json, JDBC, Proj4j
- **PHP 8** con cURL, Leaflet.js, OpenStreetMap
- **MariaDB/MySQL** con datos espaciales (POINT)
- **Docker** y Docker Compose
- **AWS RDS** (MariaDB en la nube)

## Autor

Nikita Troshko — 1º DAW, IES Juan de Garay
