USE valenbicibd;

INSERT INTO historico (
    estacion_id,
    direccion,
    bicis_disponibles,
    anclajes_libres,
    total_puestos,
    estado_operativo,
    fecha_registro,
    ubicacion
) VALUES
    (100, 'Avenida de Francia', 9, 11, 20, TRUE, NOW(), ST_GeomFromText('POINT(-0.348800 39.458100)', 4326)),
    (101, 'Calle Colon', 6, 14, 20, TRUE, NOW(), ST_GeomFromText('POINT(-0.372200 39.470700)', 4326)),
    (102, 'Jardin del Turia', 3, 17, 20, FALSE, NOW(), ST_GeomFromText('POINT(-0.363900 39.474600)', 4326));
