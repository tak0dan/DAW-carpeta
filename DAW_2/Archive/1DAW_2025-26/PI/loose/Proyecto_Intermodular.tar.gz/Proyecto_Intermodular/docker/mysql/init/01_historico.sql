CREATE DATABASE IF NOT EXISTS valenbicibd;
USE valenbicibd;

CREATE TABLE IF NOT EXISTS historico (
    id INT AUTO_INCREMENT PRIMARY KEY,
    estacion_id INT NOT NULL,
    direccion VARCHAR(255),
    bicis_disponibles INT NOT NULL,
    anclajes_libres INT NOT NULL,
    total_puestos INT NOT NULL,
    estado_operativo BOOLEAN NOT NULL,
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ubicacion POINT
);
