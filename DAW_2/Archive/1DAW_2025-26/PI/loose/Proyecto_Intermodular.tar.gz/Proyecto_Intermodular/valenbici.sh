#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
LOG_DIR="$PROJECT_DIR/logs"
DOCKER_COMPOSE="${DOCKER_COMPOSE:-docker compose}"
MAVEN="${MAVEN:-mvn}"
JAVA_HOME="${JAVA_HOME:-/usr/lib/jvm/java-26-openjdk}"
export JAVA_HOME

mkdir -p "$LOG_DIR"

log() {
    local ts
    ts="$(date '+%Y-%m-%d %H:%M:%S')"
    echo "[$ts] $*" | tee -a "$LOG_DIR/valenbici-launcher.log"
}

usage() {
    cat <<EOF
ValenbiciJDG - Lanzador del proyecto intermodular

USO:
  ./valenbici.sh recommended    Inicia todo con Docker Compose (recomendado)
  ./valenbici.sh manual         Inicia contenedores manualmente (sin compose)
  ./valenbici.sh java1          Compila y ejecuta ValenbiciAPI (T1)
  ./valenbici.sh java2          Compila y ejecuta ValenbiciAPI26T3 (T3, JFrame)
  ./valenbici.sh build          Compila todos los proyectos Java
  ./valenbici.sh stop           Detiene todos los contenedores
  ./valenbici.sh logs           Muestra los logs de todos los componentes
  ./valenbici.sh help           Muestra esta ayuda

MODOS:
  recommended  -> Usa 'docker compose up -d' para arrancar web + DB
  manual       -> Crea red, arranca MariaDB y PHP-Apache por separado
  java1        -> Compila y lanza ValenbiciAPI con mvn exec:java
  java2        -> Compila y lanza el JFrame ValenbiciAPI26T3
EOF
}

check_docker() {
    if ! command -v docker &>/dev/null; then
        log "ERROR: Docker no está instalado."
        exit 1
    fi
}

check_maven() {
    if ! command -v "$MAVEN" &>/dev/null; then
        log "ERROR: Maven no encontrado. Define MAVEN o instálalo."
        exit 1
    fi
}

cmd_recommended() {
    check_docker
    log "=== MODO RECOMENDADO: Docker Compose ==="

    if [ ! -f "$PROJECT_DIR/docker-compose.yml" ]; then
        log "ERROR: No se encuentra docker-compose.yml en $PROJECT_DIR"
        exit 1
    fi

    log "Ejecutando: $DOCKER_COMPOSE up -d"
    (cd "$PROJECT_DIR" && $DOCKER_COMPOSE up -d 2>&1 | tee -a "$LOG_DIR/valenbici-launcher.log")

    log "Esperando a que los contenedores estén listos..."
    sleep 5

    log "Ajustando permisos web..."
    docker exec valenbici-web chown -R www-data:www-data /var/www/html 2>/dev/null || true

    log "-------------------------------------------------"
    log "  Web (tabla):      http://localhost:8080/"
    log "  Web (inglés):     http://localhost:8080/?lang=en"
    log "  Mapa:             http://localhost:8080/mapearbicis.php"
    log "  MariaDB:          valenbici-db:3306"
    log "-------------------------------------------------"

    log "=== COMPLETADO ==="
}

cmd_manual() {
    check_docker
    log "=== MODO MANUAL ==="

    local net_name="valenbici-net"

    if ! docker network ls --format '{{.Name}}' | grep -q "^${net_name}$"; then
        log "Creando red: $net_name"
        docker network create "$net_name" 2>&1 | tee -a "$LOG_DIR/valenbici-launcher.log"
    else
        log "Red $net_name ya existe"
    fi

    if ! docker ps -a --format '{{.Names}}' | grep -q "^valenbici-db$"; then
        log "Iniciando MariaDB..."
        docker run -d \
            --name valenbici-db \
            --network "$net_name" \
            -e MARIADB_ROOT_PASSWORD=rootpass \
            -e MARIADB_DATABASE=valenbicibd \
            -e MARIADB_USER=valenbici \
            -e MARIADB_PASSWORD=valenbici123 \
            -v "$PROJECT_DIR/docker/mysql/init:/docker-entrypoint-initdb.d" \
            mariadb:11.4 2>&1 | tee -a "$LOG_DIR/valenbici-launcher.log"
    else
        log "Contenedor valenbici-db ya existe, iniciando..."
        docker start valenbici-db 2>&1 | tee -a "$LOG_DIR/valenbici-launcher.log" || true
    fi

    log "Esperando a que MariaDB esté lista..."
    sleep 8

    if ! docker ps -a --format '{{.Names}}' | grep -q "^valenbici-web$"; then
        log "Iniciando PHP-Apache..."
        docker run -d \
            --name valenbici-web \
            --network "$net_name" \
            -p 8080:80 \
            -v "$PROJECT_DIR/miWeb:/var/www/html" \
            php:8.3-apache 2>&1 | tee -a "$LOG_DIR/valenbici-launcher.log"
    else
        log "Contenedor valenbici-web ya existe, iniciando..."
        docker start valenbici-web 2>&1 | tee -a "$LOG_DIR/valenbici-launcher.log" || true
    fi

    log "Ajustando permisos..."
    docker exec valenbici-web chown -R www-data:www-data /var/www/html 2>/dev/null || true

    log "-------------------------------------------------"
    log "  Web (tabla):      http://localhost:8080/"
    log "  Web (inglés):     http://localhost:8080/?lang=en"
    log "  Mapa:             http://localhost:8080/mapearbicis.php"
    log "  MariaDB:          valenbici-db:3306"
    log "-------------------------------------------------"

    log "=== COMPLETADO (manual) ==="
}

cmd_java1() {
    check_maven
    log "=== COMPILANDO Y EJECUTANDO ValenbiciAPI (T1) ==="
    local num="${1:-5}"

    (cd "$PROJECT_DIR/ValenbiciAPI" && \
        $MAVEN compile exec:java -Dexec.args="$num" 2>&1 | tee -a "$LOG_DIR/valenbiciapi-run.log")

    log "ValenbiciAPI finalizado (args: $num)"
}

cmd_java2() {
    check_maven
    log "=== COMPILANDO Y EJECUTANDO ValenbiciAPI26T3 (T3 - JFrame) ==="

    (cd "$PROJECT_DIR/ValenbiciAPI26T3" && \
        $MAVEN compile exec:java 2>&1 | tee -a "$LOG_DIR/conexionbdd-run.log")

    log "ValenbiciAPI26T3 finalizado"
}

cmd_build() {
    check_maven
    log "=== COMPILANDO PROYECTOS JAVA ==="

    log "Compilando ValenbiciAPI..."
    (cd "$PROJECT_DIR/ValenbiciAPI" && $MAVEN compile -q 2>&1 | tee -a "$LOG_DIR/valenbici-launcher.log")

    log "Compilando ValenbiciAPI26T3..."
    (cd "$PROJECT_DIR/ValenbiciAPI26T3" && $MAVEN compile -q 2>&1 | tee -a "$LOG_DIR/valenbici-launcher.log")

    log "=== COMPILACION COMPLETADA ==="
}

cmd_stop() {
    check_docker
    log "=== DETENIENDO CONTENEDORES ==="

    for c in valenbici-web valenbici-db; do
        if docker ps -a --format '{{.Names}}' | grep -q "^$c$"; then
            log "Deteniendo $c..."
            docker stop "$c" 2>&1 | tee -a "$LOG_DIR/valenbici-launcher.log" || true
        fi
    done

    log "=== CONTENEDORES DETENIDOS ==="
}

cmd_logs() {
    echo "=== LOGS DE VALENBICIJDG ==="
    echo ""
    for f in "$LOG_DIR"/*.log; do
        if [ -f "$f" ]; then
            echo "--- $(basename "$f") ---"
            tail -30 "$f"
            echo ""
        fi
    done
}

case "${1:-help}" in
    recommended|auto)
        shift 2>/dev/null || true
        cmd_recommended "$@"
        ;;
    manual)
        shift 2>/dev/null || true
        cmd_manual "$@"
        ;;
    java1|t1)
        shift 2>/dev/null || true
        cmd_java1 "$@"
        ;;
    java2|t3)
        cmd_java2
        ;;
    build)
        cmd_build
        ;;
    stop)
        cmd_stop
        ;;
    logs)
        cmd_logs
        ;;
    help|--help|-h)
        usage
        ;;
    *)
        log "ERROR: Comando desconocido: $1"
        usage
        exit 1
        ;;
esac
