package es.gva.edu.iesjuandegaray.bicis;

import java.awt.EventQueue;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class ConexionBDD extends JFrame {
    private static final long serialVersionUID = 1L;
    private static final String DRIVER = "com.mysql.cj.jdbc.Driver";
    private static final String DB_URL = System.getenv().getOrDefault(
        "VALENBICI_DB_URL",
        "jdbc:mysql://localhost:3306/valenbicibd?serverTimezone=UTC"
    );
    private static final String DB_USER = System.getenv().getOrDefault("VALENBICI_DB_USER", "root");
    private static final String DB_PASS = System.getenv().getOrDefault("VALENBICI_DB_PASS", "123456789");

    private static final Logger LOG = Logger.getLogger(ConexionBDD.class.getName());

    static {
        try {
            Files.createDirectories(Paths.get("logs"));
            FileHandler fh = new FileHandler("logs/conexionbdd.log", true);
            fh.setFormatter(new SimpleFormatter());
            fh.setLevel(Level.ALL);
            LOG.addHandler(fh);
            LOG.setLevel(Level.ALL);
            LOG.setUseParentHandlers(false);
            LOG.info("=== INICIO ConexionBDD ===");
        } catch (IOException e) {
            System.err.println("No se ha podido inicializar el log: " + e.getMessage());
        }
    }

    private JPanel contentPane;
    private JTextField textFieldNEstaciones;
    private JTextArea textAreaDatos;
    private JLabel lblEstadoConexion;
    private JLabel lblEstadoOperacion;

    private transient Connection connection;
    private transient DatosJSon datosJSon;

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                ConexionBDD frame = new ConexionBDD();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public ConexionBDD() {
        setTitle("Conexion Valenbici - MySQL");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 760, 520);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(8, 8, 8, 8));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblNumero = new JLabel("Introduce el numero de estaciones a consultar:");
        lblNumero.setBounds(16, 16, 290, 22);
        contentPane.add(lblNumero);

        textFieldNEstaciones = new JTextField("3");
        textFieldNEstaciones.setBounds(320, 16, 90, 24);
        contentPane.add(textFieldNEstaciones);
        textFieldNEstaciones.setColumns(10);

        JButton btnDatos = new JButton("Datos");
        btnDatos.setBounds(16, 60, 150, 30);
        btnDatos.addActionListener(event -> cargarDatos());
        contentPane.add(btnDatos);

        JButton btnConectar = new JButton("Conectar");
        btnConectar.setBounds(16, 106, 150, 30);
        btnConectar.addActionListener(event -> conectar());
        contentPane.add(btnConectar);

        JButton btnCrearTabla = new JButton("Crear tabla");
        btnCrearTabla.setBounds(16, 152, 150, 30);
        btnCrearTabla.addActionListener(event -> crearTablaSiNoExiste());
        contentPane.add(btnCrearTabla);

        JButton btnAnadir = new JButton("Anadir a BDD");
        btnAnadir.setBounds(16, 198, 150, 30);
        btnAnadir.addActionListener(event -> insertarDatos());
        contentPane.add(btnAnadir);

        JButton btnLimpiar = new JButton("Limpiar");
        btnLimpiar.setBounds(16, 244, 150, 30);
        btnLimpiar.addActionListener(event -> textAreaDatos.setText(""));
        contentPane.add(btnLimpiar);

        JLabel lblDatos = new JLabel("Salida de datos y mensajes:");
        lblDatos.setBounds(196, 60, 250, 22);
        contentPane.add(lblDatos);

        textAreaDatos = new JTextArea();
        textAreaDatos.setEditable(false);
        textAreaDatos.setLineWrap(true);
        textAreaDatos.setWrapStyleWord(true);

        JScrollPane scrollPane = new JScrollPane(textAreaDatos);
        scrollPane.setBounds(196, 90, 530, 270);
        contentPane.add(scrollPane);

        JLabel lblEstado = new JLabel("Estado conexion:");
        lblEstado.setBounds(196, 380, 120, 22);
        contentPane.add(lblEstado);

        lblEstadoConexion = new JLabel("Sin conectar");
        lblEstadoConexion.setBounds(320, 380, 406, 22);
        contentPane.add(lblEstadoConexion);

        JLabel lblOperacion = new JLabel("Estado operacion:");
        lblOperacion.setBounds(196, 416, 120, 22);
        contentPane.add(lblOperacion);

        lblEstadoOperacion = new JLabel("Primero carga datos y conecta con la base de datos.");
        lblEstadoOperacion.setBounds(320, 416, 406, 22);
        contentPane.add(lblEstadoOperacion);
    }

    private void cargarDatos() {
        int numeroEstaciones;

        try {
            numeroEstaciones = Math.max(1, Integer.parseInt(textFieldNEstaciones.getText().trim()));
        } catch (NumberFormatException ex) {
            LOG.warning("Numero de estaciones no valido introducido por el usuario");
            mostrarError("Numero de estaciones no valido.");
            return;
        }

        LOG.info("Cargando datos para " + numeroEstaciones + " estaciones");
        datosJSon = new DatosJSon(numeroEstaciones);
        textAreaDatos.setText(datosJSon.getDatos());
        int count = datosJSon.getEstaciones().size();
        lblEstadoOperacion.setText("Datos descargados: " + count + " estaciones.");
        LOG.info("Datos descargados: " + count + " estaciones");
        logAccion("DATOS", "Descargadas " + count + " estaciones de " + numeroEstaciones + " solicitadas");
    }

    private void conectar() {
        LOG.info("Intentando conectar a " + DB_URL + " usuario=" + DB_USER);
        try {
            Class.forName(DRIVER);
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
            lblEstadoConexion.setText("Conectado a " + DB_URL);
            lblEstadoOperacion.setText("Conexion establecida correctamente.");
            LOG.info("Conexion establecida correctamente");
            logAccion("BDD", "Conectado a " + DB_URL);
        } catch (ClassNotFoundException ex) {
            LOG.severe("Driver JDBC no encontrado: " + ex.getMessage());
            mostrarError("No se ha encontrado el driver JDBC: " + ex.getMessage());
        } catch (SQLException ex) {
            LOG.severe("Error al conectar con MySQL: " + ex.getMessage());
            mostrarError("No se ha podido conectar con MySQL: " + ex.getMessage());
        }
    }

    private void crearTablaSiNoExiste() {
        if (!asegurarConexion()) {
            return;
        }

        String sql = """
            CREATE TABLE IF NOT EXISTS historico (
                id INT AUTO_INCREMENT PRIMARY KEY,
                estacion_id INT NOT NULL,
                direccion VARCHAR(255),
                bicis_disponibles INT NOT NULL,
                anclajes_libres INT NOT NULL,
                total_puestos INT NOT NULL,
                estado_operativo BOOLEAN NOT NULL,
                fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                ubicacion POINT
            )
            """;

        try (Statement statement = connection.createStatement()) {
            statement.execute(sql);
            lblEstadoOperacion.setText("Tabla historico lista para usar.");
            LOG.info("Tabla historico creada/verificada");
            logAccion("BDD", "Tabla historico creada o ya existente");
        } catch (SQLException ex) {
            LOG.severe("No se ha podido crear la tabla: " + ex.getMessage());
            mostrarError("No se ha podido crear la tabla: " + ex.getMessage());
        }
    }

    private void insertarDatos() {
        if (!asegurarConexion()) {
            return;
        }

        if (datosJSon == null || datosJSon.getEstaciones().isEmpty()) {
            LOG.warning("Intento de insertar sin datos cargados");
            mostrarError("Primero pulsa Datos para descargar las estaciones.");
            return;
        }

        String sql = """
            INSERT INTO historico (
                estacion_id,
                direccion,
                bicis_disponibles,
                anclajes_libres,
                total_puestos,
                estado_operativo,
                fecha_registro,
                ubicacion
            ) VALUES (?, ?, ?, ?, ?, ?, NOW(), ST_GeomFromText(?, 4326))
            """;

        List<DatosJSon.StationSnapshot> estaciones = datosJSon.getEstaciones();
        int inserted = 0;

        LOG.info("Insertando " + estaciones.size() + " estaciones en historico");

        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            for (DatosJSon.StationSnapshot estacion : estaciones) {
                statement.setInt(1, estacion.stationNumber());
                statement.setString(2, estacion.address());
                statement.setInt(3, estacion.availableBikes());
                statement.setInt(4, estacion.freeDocks());
                statement.setInt(5, estacion.totalDocks());
                statement.setBoolean(6, estacion.open());
                statement.setString(7, estacion.toPointWkt());
                statement.addBatch();
                LOG.fine("Preparada insercion: estacion #" + estacion.stationNumber());
            }

            int[] result = statement.executeBatch();
            inserted = result.length;
            lblEstadoOperacion.setText("Insertadas " + inserted + " estaciones en historico.");
            LOG.info("Insertadas " + inserted + " estaciones en historico");
            logAccion("INSERT", "Insertadas " + inserted + " estaciones en historico");
        } catch (SQLException ex) {
            LOG.severe("Error al insertar datos: " + ex.getMessage());
            mostrarError("No se han podido insertar los datos: " + ex.getMessage());
        }
    }

    private boolean asegurarConexion() {
        try {
            if (connection == null || connection.isClosed()) {
                mostrarError("Primero debes conectar con la base de datos.");
                return false;
            }
        } catch (SQLException ex) {
            mostrarError("No se ha podido comprobar la conexion: " + ex.getMessage());
            return false;
        }

        return true;
    }

    private void mostrarError(String mensaje) {
        lblEstadoOperacion.setText(mensaje);
        JOptionPane.showMessageDialog(this, mensaje, "Valenbici", JOptionPane.ERROR_MESSAGE);
    }

    private void logAccion(String tipo, String detalle) {
        LOG.info("[" + tipo + "] " + detalle);
    }
}
