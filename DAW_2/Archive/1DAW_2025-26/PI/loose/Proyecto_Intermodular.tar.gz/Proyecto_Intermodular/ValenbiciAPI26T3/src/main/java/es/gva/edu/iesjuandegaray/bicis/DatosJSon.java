package es.gva.edu.iesjuandegaray.bicis;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;

public class DatosJSon {
    private static final String API_URL =
        "https://geoportal.valencia.es/server/rest/services/OPENDATA/Trafico/MapServer/228/query"
            + "?where=1%3D1"
            + "&outFields=*"
            + "&returnGeometry=true"
            + "&f=json";

    private static final Logger LOG = Logger.getLogger(DatosJSon.class.getName());

    private final List<StationSnapshot> estaciones = new ArrayList<>();
    private String datos = "";

    public DatosJSon(int numeroEstaciones) {
        mostrarDatos(numeroEstaciones);
    }

    public void mostrarDatos(int numeroEstaciones) {
        estaciones.clear();
        datos = "";

        LOG.info("Consultando API para " + numeroEstaciones + " estaciones");
        long inicio = System.currentTimeMillis();

        try (CloseableHttpClient httpClient = HttpClients.createDefault()) {
            HttpGet request = new HttpGet(API_URL);
            HttpResponse response = httpClient.execute(request);
            int status = response.getStatusLine().getStatusCode();
            long duracion = System.currentTimeMillis() - inicio;

            if (status != 200) {
                datos = "La API ha devuelto HTTP " + status + ".";
                LOG.warning("API devolvio HTTP " + status);
                return;
            }

            HttpEntity entity = response.getEntity();
            if (entity == null) {
                datos = "La API no ha devuelto contenido.";
                LOG.warning("API sin contenido");
                return;
            }

            String result = EntityUtils.toString(entity, StandardCharsets.UTF_8);
            LOG.info("JSON descargado en " + duracion + "ms (" + result.length() + " bytes)");

            JSONObject jsonObject = new JSONObject(result);
            JSONArray features = jsonObject.optJSONArray("features");

            if (features == null || features.length() == 0) {
                datos = "No se han encontrado estaciones en la respuesta JSON.";
                LOG.warning("JSON sin estaciones");
                return;
            }

            int limite = Math.min(Math.max(1, numeroEstaciones), features.length());
            LOG.info("Procesando " + limite + " de " + features.length() + " estaciones");
            StringBuilder sb = new StringBuilder();
            int convertidas = 0;

            for (int i = 0; i < limite; i++) {
                JSONObject feature = features.getJSONObject(i);
                JSONObject attributes = feature.optJSONObject("attributes");
                JSONObject geometry = feature.optJSONObject("geometry");

                if (attributes == null) {
                    continue;
                }

                int stationNumber = attributes.optInt("number", 0);
                String address = attributes.optString("address", "Sin direccion");
                int available = attributes.optInt("available", 0);
                int free = attributes.optInt("free", 0);
                int total = attributes.optInt("total", available + free);
                boolean open = "T".equalsIgnoreCase(attributes.optString("open", "F"));
                String updatedAt = attributes.optString("updated_at", "Sin fecha");
                double x = geometry != null ? geometry.optDouble("x", 0.0) : 0.0;
                double y = geometry != null ? geometry.optDouble("y", 0.0) : 0.0;

                double latitude;
                double longitude;

                if (looksLikeLonLat(x, y)) {
                    latitude = y;
                    longitude = x;
                    LOG.fine("Estacion #" + stationNumber + ": coordenadas directas (" + latitude + ", " + longitude + ")");
                } else {
                    double[] latLon = ConversionGeoLongLat.conversionPair(x, y);
                    latitude = latLon[0];
                    longitude = latLon[1];
                    convertidas++;
                    LOG.fine("Estacion #" + stationNumber + ": UTM (" + x + ", " + y + ") -> GPS (" + latitude + ", " + longitude + ")");
                }

                StationSnapshot snapshot = new StationSnapshot(
                    stationNumber, address, available, free, total, open, updatedAt, latitude, longitude
                );
                estaciones.add(snapshot);

                sb.append("Estacion #").append(snapshot.stationNumber()).append('\n')
                    .append("Direccion: ").append(snapshot.address()).append('\n')
                    .append("Bicis disponibles: ").append(snapshot.availableBikes()).append('\n')
                    .append("Anclajes libres: ").append(snapshot.freeDocks()).append('\n')
                    .append("Puestos totales: ").append(snapshot.totalDocks()).append('\n')
                    .append("Estado operativo: ").append(snapshot.open() ? "Abierta" : "Cerrada").append('\n')
                    .append("Actualizado: ").append(snapshot.updatedAt()).append('\n')
                    .append("Latitud: ").append(String.format("%.6f", snapshot.latitude())).append('\n')
                    .append("Longitud: ").append(String.format("%.6f", snapshot.longitude())).append("\n\n");
            }

            if (convertidas > 0) {
                LOG.info("Coordenadas convertidas UTM->GPS: " + convertidas);
            }
            datos = sb.toString();
            LOG.info("Procesadas " + estaciones.size() + " estaciones correctamente");
        } catch (IOException ex) {
            LOG.severe("Error al descargar JSON: " + ex.getMessage());
            datos = "Error al descargar el JSON: " + ex.getMessage();
        } catch (RuntimeException ex) {
            LOG.severe("Error al procesar JSON: " + ex.getMessage());
            datos = "Error al procesar el JSON: " + ex.getMessage();
        }
    }

    private boolean looksLikeLonLat(double x, double y) {
        return x >= -180 && x <= 180 && y >= -90 && y <= 90;
    }

    public String getDatos() {
        return datos;
    }

    public List<StationSnapshot> getEstaciones() {
        return Collections.unmodifiableList(estaciones);
    }

    public record StationSnapshot(
        int stationNumber,
        String address,
        int availableBikes,
        int freeDocks,
        int totalDocks,
        boolean open,
        String updatedAt,
        double latitude,
        double longitude
    ) {
        public String toPointWkt() {
            return "POINT(" + longitude + " " + latitude + ")";
        }
    }
}
