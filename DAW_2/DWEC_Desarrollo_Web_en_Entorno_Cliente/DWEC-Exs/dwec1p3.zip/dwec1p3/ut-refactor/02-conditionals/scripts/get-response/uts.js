// UT's for getResponse(): manual verification (compare expectedResponse vs response)

const tests = [
    { score: 75, machineActive: false, expectedResponse: 'Please switch the machine on.' },
    { score: 75, machineActive: true, expectedResponse: 'That\'s a great score, you really know your stuff.' },
    { score: 150, machineActive: true, expectedResponse: 'This is not possible, an error has occurred.' },
];

// Table header (legend)
console.log('| testNum | succes | score | machineActive | expectedResponse | response |');
console.log('|-|-|-|-|-|-|');

// One line per test
for (let i = 0; i < tests.length; i++) {
    const test = tests[i];
    let succes = false;

    const response = getResponse(test.score, test.machineActive);
        if(test.expectedResponse === response){
        succes = true;
    }else{
        succes = false;
    }
    console.log(`| ${ i + 1 }  | ${ succes }| ${ test.score } | ${ test.machineActive } | ${ test.expectedResponse } | ${ response } |`);
}