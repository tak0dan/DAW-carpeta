function getResponse(score, machineActive){
    let response;

    // Add your code here
    //{{-------------------------------------------------------

    //console.log("machineActive: " + machineActive);
    //console.log("score: " + score);

     response = !machineActive
        ? 'Please switch the machine on.'
        : score < 0 || score > 100
            ? 'This is not possible, an error has occurred.'
            : score <= 19 ?
                'That was a terrible score - total fail!'
                : score <=39 ?
                    'You know some things, but it\'s a pretty bad score. Needs improvement.'
                    :score <=69 ?
                        'You did a passable job, not bad'
                        : score <= 89 ?
                            'That\'s a great score, you really know your stuff.'
                            : 'What an amazing score! Did you cheat? Are you for real?'

        
	//console.log("final response: " + response);

    //}}-------------------------------------------------------
    // Don't edit the code below here!

    const body = document.querySelector('body');
    let para1 = document.createElement('p');
    let para2 = document.createElement('p');
    para1.textContent = `Your score is ${ score }`;
    para2.textContent = response;
    body.appendChild(para1);
    body.appendChild(para2);

    return response;
}
