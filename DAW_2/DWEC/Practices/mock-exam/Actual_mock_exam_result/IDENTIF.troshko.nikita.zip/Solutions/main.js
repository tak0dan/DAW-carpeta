//console.log("Hola");

//array_test=([8, 7,8,9]);
//for(let a = 0; a<=array_test.length-1; a++){
//  console.log(typeof array_test[a]);
//  console.log(array_test[a]);
//}


function myIndex(arr, target, num = 1) {

    if (!Number.isInteger(num) || num < 1) {
        num = 1;
    }

    let count = 0;

    for (let i = arr.length - 1; i >= 0; i--) {

        if (arr[i] === target) {
            count++;

            if (count === num) {
                return i;
            }
        }
    }

    return 1;
}

console.log(myIndex([8, 8, 7, 8, 8, 7,8,9], 8, 2)); // 4

//console.log(myIndex([8, 7,8,9], 8)); 
// Original testing syntax was console.log(myIndex([8, 7,8,9], 8); 
// which led to an error. 
console.log("testNum | okKo | arr" 
  + "| target | out | expectedOut | num");


let testNum = 0;
let testsPassed = 0;

function ut(arr, target, expectedOut, num){
  testNum++;
  let okKo;
  let out = myIndex(arr, target, num);
  if(out === expectedOut){
    okKo = "OK";
    testsPassed++;
  }else{
    okKo = "KO!";
  }
  console.log(testNum + " | " +okKo +" | "+ arr + 
    " | "+target+" | "+out+" | "+expectedOut+" | "+num);

}

//UT BLOCK 1.1
console.log("Block 1.1");
ut([8, 7,8,9], 8, 2); //Basic test
ut([1, 2,3,4], 1, 2); //incorrect expectedOut
ut([8, 7,8,9], 6, 1); //missing target in array test

//TODO: fix the bug: myIndex does not correctly return the 1 in case if 
//target was not found.
// ╭─niktro2@lliurex-hpprodesk600g1sff in ~ took 0s
// ╰─λ node /home/niktro2/Solutions/main.js
//testNum | okKo | arr| target | out | expectedOut
//1 | OK | 8,7,8,9 | 8 | 2 | 2
//2 | KO! | 1,2,3,4 | 1 | undefined | 2
//3 | OK | 8,7,8,9 | 7 | 1 | 1
//Tests passed: 2/3


//Declaring aDevolver as 1 is a workaround, but better approach is possible.
//UT BLOCK 1.2
console.log("Block 1.2")
ut([8, 7,"a",9], "a", 2); //Basic test using string
ut([1, 2,3,4], 1, "a"); //Incorrect expectedOut
ut([1, 2,3,4], 1); //Missing expectedOut
ut( "", "" , ""); //Empty function
ut( [], "" , 1);  //Empty array
ut( [1,1,], "" , 2);  //Searching skipped position in array
ut( [1,1,""], "" , 2);  //Searching empty position in array




console.log("Tests passed: "+testsPassed+"/"+testNum);


//Test case after implementing the num entry parameter 
//into the myIndex function
console.log(myIndex([8, 8, 7, 8, 8, 7,8,9], 8, 2)); // 4

//UT tests after implementation
testNum = 0;
testsPassed = 0;
// UT BLOCK 2.1
console.log("Block 2.1");
ut([8, 7,8,9], 8, 2, 1); //Basic test
ut([8, 7,8,9], 8, 2); //Basic test, missing num (testing the default)
ut([1, 2,3,4], 1, 2); //incorrect expectedOut
ut([1, 2,3,4], 3, 2,3); //Searching for number more times than number exists
ut([8, 7,8,9], 6, 1); //missing target in array test

//UT BLOCK 2.2 (copy of the UT BLOCK 1.2 + num use)
console.log("Block 2.1");
ut([8, 7,"a",9, "a"], "a", 2); //Basic test using string with no num
ut([8, 7,"a",9, "a"], "a", 2, 2); //Basic test using string
ut([1, 2,3,4], 1, "a"); //Incorrect expectedOut
ut([1, 2,3,4], 1); //Missing expectedOut
ut( "", "" , "", 0); //Searching 0 position
ut( [], "" , 1, 1);  //Empty array, position 1
ut( [1,1,], "" , 2);  //Searching skipped position in array
ut( [1,1,""], "" , 2, 1);  //Searching empty position in array



console.log("Tests passed(testing num use): "+testsPassed+"/"+testNum);
